﻿Imports System.Security.Cryptography.X509Certificates

Public Class Form1
    Dim speed As Integer
    Dim road(7) As PictureBox
    Dim score As Integer = 0
    Dim exp2(6) As Image
    Public aux = 0
    Public comecou = False
    Public movXcar1 = 0
    Public movXcar2 = 0
    Public movXcar3 = 0
    Public powerUpActive = False
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        movXcar1 = 0
        movXcar2 = 0
        movXcar3 = 0
        speed = 6
        aux = 0
        road(0) = PictureBox1
        road(1) = PictureBox2
        road(2) = PictureBox3
        road(3) = PictureBox4
        road(4) = PictureBox5
        road(5) = PictureBox6
        road(6) = PictureBox7
        road(7) = PictureBox8

        exp2(0) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao1.png")
        exp2(1) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao2.png")
        exp2(2) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao3.png")
        exp2(3) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao4.png")
        exp2(4) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao5.png")
        exp2(5) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao6.png")
        exp2(6) = Image.FromFile("D:\14721-Marcelo\2P\VB\explosao\explosao7.png")
        If comecou = False Then
            Endgame()
        End If

    End Sub

    Private Sub Endgame()
        'para os timers e mostra a tela de fim do jogo
        If comecou Then
            Label3.Text = "GAMEOVER"
            Button1.Text = "Restart"
        Else
            comecou = True
        End If


        Button1.Visible = True
        Label3.Visible = True
        RoadMover.Stop()
        RacerMover.Stop()
        RacerMover2.Stop()
        RacerMover3.Stop()
        mudarDire1.Stop()
        'Implementei isto para o carro não deslizar
        RightSide.Stop()
        LeftSide.Stop()
        DownSide.Stop()
        Upside.Stop()
        'power up
        powerUp.Stop()
        powerUpAtv.Stop()
        colocarPowerUP.Stop()
    End Sub

    Private Sub RoadMover_Tick(sender As Object, e As EventArgs) Handles RoadMover.Tick
        'faz as linhas da estrada mover, quando as linhas passam da tela, ele volta para cima de todo, um ciclo
        For x As Integer = 0 To 7
            road(x).Top += speed
            If road(x).Top >= Me.Height Then
                road(x).Top = -road(x).Height
            End If
        Next

        'muda a velocidade do carro dependendo do score
        If score > 10 And score < 30 Then
            speed = 8
        End If
        If score > 30 And score < 50 Then
            speed = 10
        End If
        If score > 50 And score < 70 Then
            speed = 11
        End If
        If score > 50 Then
            speed = 12
        End If

        'verifica se o carro colidiu com alguma coisa
        Label2.Text = "Speed" & speed
        If (car.Bounds.IntersectsWith(race1.Bounds) Or car.Bounds.IntersectsWith(race2.Bounds) Or car.Bounds.IntersectsWith(race3.Bounds)) Then
            If powerUpActive = False Then
                Dim ponto = New Point
                ponto.X = car.Location.X - 38
                ponto.Y = car.Location.Y - 25
                exp.Location = ponto
                exp.Visible = True
                explosao.Start()
                Endgame()
            End If
        End If

        If powerUpActive = True Then
            If car.BackColor = Color.Black Then
                car.BackColor = Color.Yellow
            ElseIf car.BackColor = Color.Yellow Then
                car.BackColor = Color.Black
            End If
        Else
            car.BackColor = Color.Black
        End If

    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        ' ativa os eventos de mover o carro
        If e.KeyCode = Keys.Right Then
            RightSide.Start()
        End If

        If e.KeyCode = Keys.Left Then
            LeftSide.Start()
        End If

        If e.KeyCode = Keys.Up Then
            Upside.Start()
        End If

        If e.KeyCode = Keys.Down Then
            DownSide.Start()
        End If
    End Sub

    Private Sub RightSide_Tick(sender As Object, e As EventArgs) Handles RightSide.Tick
        'move o carro para a direita
        If (car.Location.X < 295) Then
            car.Left += 5
        End If

    End Sub

    Private Sub LeftSide_Tick(sender As Object, e As EventArgs) Handles LeftSide.Tick
        'move o carro para a esquerda 
        If (car.Location.X > 0) Then
            car.Left -= 5
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        LeftSide.Stop()
        RightSide.Stop()
        Upside.Stop()
        DownSide.Stop()
    End Sub

    Private Sub RacerMover_Tick(sender As Object, e As EventArgs) Handles RacerMover.Tick


        If race1.Bounds.IntersectsWith(race2.Bounds) Or race1.Bounds.IntersectsWith(race3.Bounds) Then
            'If movXcar1 = 2 Then
            ' movXcar1 = 1
            ' ElseIf movXcar1 = 1 Then
            '     movXcar1 = 2
            'End If
            movXcar1 *= -1
        End If

        'If (race1.Location.X + race1.Size.Width + 10 < 350 Then
        If (race1.Location.X + race1.Size.Width + movXcar1) >= 350 Then
            movXcar1 = 0
        ElseIf (race1.Location.X + movXcar1) <= 0 Then
            'race1.Left -= 1
            movXcar1 = 0
        Else
            'nada
        End If
        race1.Left += movXcar1

        'o carro é mais lento que o jogador
        race1.Top += speed / 2
        'verifica se o carro saiu da tela
        If race1.Top >= Me.Height Then
            'muda a score
            score += 1
            Label1.Text = "Score" & score

            'coloca o carro num lugar aleatorio em cima
            Dim point = New Point
            Dim ran = New Random
            point.Y = 0
            point.X = ran.Next(0, 289)
            race1.Location = point
        End If
    End Sub

    Private Sub RacerMover2_Tick(sender As Object, e As EventArgs) Handles RacerMover2.Tick
        If race2.Bounds.IntersectsWith(race1.Bounds) Or race2.Bounds.IntersectsWith(race3.Bounds) Then
            'If movXcar2 = 2 Then
            ' movXcar2 = 1
            ' ElseIf movXcar2 = 1 Then
            '     movXcar2 = 2
            'End If
            movXcar2 *= -1
        End If

        'If (race2.Location.X + race2.Size.Width + 10 < 350 Then
        If (race2.Location.X + race2.Size.Width + movXcar2) >= 350 Then
            movXcar2 = 0
        ElseIf (race2.Location.X + movXcar2) <= 0 Then
            'race2.Left -= 1
            movXcar2 = 0
        Else
            'nada
        End If
        race2.Left += movXcar2
        
        'mesmo que o de cima so que para o carro2
        race2.Top += speed / 3
        If race2.Top >= Me.Height Then
            score += 1
            Label2.Text = "Score" & score

            Dim point = New Point
            Dim ran = New Random
            point.Y = 0
            point.X = ran.Next(0, 289)
            race2.Location = point
        End If
    End Sub

    Private Sub RacerMover3_Tick(sender As Object, e As EventArgs) Handles RacerMover3.Tick
        If race3.Bounds.IntersectsWith(race2.Bounds) Or race3.Bounds.IntersectsWith(race1.Bounds) Then
            'If movXcar2 = 2 Then
            ' movXcar2 = 1
            ' ElseIf movXcar2 = 1 Then
            '     movXcar2 = 2
            'End If
            movXcar3 *= -1
        End If

        'If (race2.Location.X + race2.Size.Width + 10 < 350 Then
        If (race3.Location.X + race3.Size.Width + movXcar3) >= 350 Then
            movXcar3 = 0
        ElseIf (race3.Location.X + movXcar3) <= 0 Then
            'race2.Left -= 1
            movXcar3 = 0
        Else
            'nada
        End If
        race3.Left += movXcar3
        race3.Top += speed / 3
        'mesmo que o de cima so que para o carro3
        If race3.Top >= Me.Height Then
            score += 1
            Label2.Text = "Score" & score

            Dim point = New Point
            Dim ran = New Random
            point.Y = 0
            point.X = ran.Next(0, 289)
            race3.Location = point

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'reinicia o jogo
        score = 0
        Me.Controls.Clear()
        InitializeComponent()
        Form1_Load(e, e)
    End Sub

    Private Sub explosao_Tick(sender As Object, e As EventArgs) Handles explosao.Tick
        aux += 1
        exp.Image = exp2(aux)
        If aux >= 6 Then
            exp.Visible = False
            car.Visible = False
            explosao.Stop()
        End If
    End Sub

    Private Sub Upside_Tick(sender As Object, e As EventArgs) Handles Upside.Tick
        If (car.Location.Y > 0) Then
            car.Top -= 5
        End If
    End Sub

    Private Sub DownSide_Tick(sender As Object, e As EventArgs) Handles DownSide.Tick
        If (car.Location.Y < Me.Height - car.Size.Height - 30) Then
            car.Top += 5
        End If
    End Sub

    Public Function mudarD()
        Dim rand = New Random
        Return rand.Next(0, 3)
    End Function

    Private Sub mudarDire1_Tick(sender As Object, e As EventArgs) Handles mudarDire1.Tick
        movXcar1 = mudarD()
        movXcar2 = mudarD()
        movXcar3 = mudarD()
    End Sub

    Private Sub powerUp_Tick(sender As Object, e As EventArgs) Handles powerUp.Tick
        powerUp1.Top += 1
        If powerUp1.Bounds.IntersectsWith(car.Bounds) Then
            powerUpActive = True
            powerUpAtv.Start()
            car.BackColor = Color.Yellow
            powerUp1.Visible = False
            powerUp1.Enabled = False
            powerUp.Stop()
        End If

        If powerUp1.Top >= Me.Height Then
            powerUp.Stop()
            powerUp1.Visible = False
            powerUp1.Enabled = False
        End If
    End Sub

    Private Sub colocarPowerUP_Tick(sender As Object, e As EventArgs) Handles colocarPowerUP.Tick
        Dim point = New Point
        Dim ran = New Random
        point.Y = 0
        point.X = ran.Next(0, 289)
        powerUp1.Visible = True
        powerUp1.Enabled = True
        powerUp1.Location = point
        powerUp.Start()
    End Sub

    Private Sub powerUpAtv_Tick(sender As Object, e As EventArgs) Handles powerUpAtv.Tick
        car.BackColor = Color.Black
        powerUpActive = False
        powerUpAtv.Stop()
    End Sub
End Class
