﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox8 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        race2 = New PictureBox()
        race1 = New PictureBox()
        race3 = New PictureBox()
        car = New PictureBox()
        RoadMover = New Timer(components)
        RightSide = New Timer(components)
        LeftSide = New Timer(components)
        RacerMover = New Timer(components)
        RacerMover2 = New Timer(components)
        RacerMover3 = New Timer(components)
        Label3 = New Label()
        Button1 = New Button()
        exp = New PictureBox()
        explosao = New Timer(components)
        powerUp1 = New PictureBox()
        powerUp = New Timer(components)
        Upside = New Timer(components)
        DownSide = New Timer(components)
        mudarDire1 = New Timer(components)
        colocarPowerUP = New Timer(components)
        powerUpAtv = New Timer(components)
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(race2, ComponentModel.ISupportInitialize).BeginInit()
        CType(race1, ComponentModel.ISupportInitialize).BeginInit()
        CType(race3, ComponentModel.ISupportInitialize).BeginInit()
        CType(car, ComponentModel.ISupportInitialize).BeginInit()
        CType(exp, ComponentModel.ISupportInitialize).BeginInit()
        CType(powerUp1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ButtonHighlight
        PictureBox1.Location = New Point(108, -73)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(13, 139)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = SystemColors.ButtonHighlight
        PictureBox2.Location = New Point(108, 83)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(13, 139)
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = SystemColors.ButtonHighlight
        PictureBox3.Location = New Point(108, 242)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(13, 139)
        PictureBox3.TabIndex = 2
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = SystemColors.ButtonHighlight
        PictureBox4.Location = New Point(108, 401)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(13, 139)
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = SystemColors.ButtonHighlight
        PictureBox5.Location = New Point(223, 401)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(13, 139)
        PictureBox5.TabIndex = 7
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = SystemColors.ButtonHighlight
        PictureBox6.Location = New Point(223, 242)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(13, 139)
        PictureBox6.TabIndex = 6
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = SystemColors.ButtonHighlight
        PictureBox7.Location = New Point(223, 83)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(13, 139)
        PictureBox7.TabIndex = 5
        PictureBox7.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = SystemColors.ButtonHighlight
        PictureBox8.Location = New Point(223, -73)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(13, 139)
        PictureBox8.TabIndex = 4
        PictureBox8.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Agency FB", 18F, FontStyle.Bold)
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(10, 9)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 31)
        Label1.TabIndex = 8
        Label1.Text = "SCORE 0"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Agency FB", 18F, FontStyle.Bold)
        Label2.ForeColor = SystemColors.Control
        Label2.Location = New Point(253, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(79, 31)
        Label2.TabIndex = 9
        Label2.Text = "SPEED 0"
        ' 
        ' race2
        ' 
        race2.Image = My.Resources.Resources.carro2
        race2.Location = New Point(155, 43)
        race2.Name = "race2"
        race2.Size = New Size(42, 73)
        race2.SizeMode = PictureBoxSizeMode.Zoom
        race2.TabIndex = 11
        race2.TabStop = False
        ' 
        ' race1
        ' 
        race1.Image = My.Resources.Resources.carro4
        race1.Location = New Point(271, 73)
        race1.Name = "race1"
        race1.Size = New Size(42, 73)
        race1.SizeMode = PictureBoxSizeMode.Zoom
        race1.TabIndex = 12
        race1.TabStop = False
        ' 
        ' race3
        ' 
        race3.Image = My.Resources.Resources.carro3
        race3.Location = New Point(24, 92)
        race3.Name = "race3"
        race3.Size = New Size(42, 73)
        race3.SizeMode = PictureBoxSizeMode.Zoom
        race3.TabIndex = 13
        race3.TabStop = False
        ' 
        ' car
        ' 
        car.BackColor = SystemColors.ActiveCaptionText
        car.Image = My.Resources.Resources.carro1
        car.Location = New Point(155, 359)
        car.Name = "car"
        car.Size = New Size(42, 73)
        car.SizeMode = PictureBoxSizeMode.Zoom
        car.TabIndex = 14
        car.TabStop = False
        ' 
        ' RoadMover
        ' 
        RoadMover.Enabled = True
        RoadMover.Interval = 10
        ' 
        ' RightSide
        ' 
        RightSide.Interval = 10
        ' 
        ' LeftSide
        ' 
        LeftSide.Interval = 10
        ' 
        ' RacerMover
        ' 
        RacerMover.Enabled = True
        RacerMover.Interval = 10
        ' 
        ' RacerMover2
        ' 
        RacerMover2.Enabled = True
        RacerMover2.Interval = 10
        ' 
        ' RacerMover3
        ' 
        RacerMover3.Enabled = True
        RacerMover3.Interval = 10
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = SystemColors.ButtonHighlight
        Label3.Font = New Font("Agency FB", 36F, FontStyle.Bold)
        Label3.ForeColor = Color.Firebrick
        Label3.Location = New Point(72, 149)
        Label3.Name = "Label3"
        Label3.Size = New Size(199, 59)
        Label3.TabIndex = 15
        Label3.Text = "Car Racing"
        Label3.Visible = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.Salmon
        Button1.BackgroundImageLayout = ImageLayout.Center
        Button1.Font = New Font("Agency FB", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(105, 242)
        Button1.Name = "Button1"
        Button1.Size = New Size(131, 45)
        Button1.TabIndex = 16
        Button1.Text = "PLAY"
        Button1.UseVisualStyleBackColor = False
        Button1.Visible = False
        ' 
        ' exp
        ' 
        exp.Image = My.Resources.Resources.explosao1
        exp.Location = New Point(242, 211)
        exp.Name = "exp"
        exp.Size = New Size(139, 133)
        exp.SizeMode = PictureBoxSizeMode.Zoom
        exp.TabIndex = 17
        exp.TabStop = False
        exp.Visible = False
        ' 
        ' explosao
        ' 
        explosao.Interval = 50
        ' 
        ' powerUp1
        ' 
        powerUp1.Image = My.Resources.Resources.estrela
        powerUp1.Location = New Point(24, 359)
        powerUp1.Name = "powerUp1"
        powerUp1.Size = New Size(42, 44)
        powerUp1.SizeMode = PictureBoxSizeMode.Zoom
        powerUp1.TabIndex = 18
        powerUp1.TabStop = False
        powerUp1.Visible = False
        ' 
        ' powerUp
        ' 
        powerUp.Interval = 10
        ' 
        ' Upside
        ' 
        Upside.Interval = 10
        ' 
        ' DownSide
        ' 
        DownSide.Interval = 10
        ' 
        ' mudarDire1
        ' 
        mudarDire1.Enabled = True
        mudarDire1.Interval = 750
        ' 
        ' colocarPowerUP
        ' 
        colocarPowerUP.Enabled = True
        colocarPowerUP.Interval = 10000
        ' 
        ' powerUpAtv
        ' 
        powerUpAtv.Interval = 5000
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ControlDarkDark
        ClientSize = New Size(334, 461)
        Controls.Add(powerUp1)
        Controls.Add(exp)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(car)
        Controls.Add(race3)
        Controls.Add(race1)
        Controls.Add(race2)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        MaximumSize = New Size(350, 500)
        MinimumSize = New Size(350, 500)
        Name = "Form1"
        Text = "Car Racing Game"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(race2, ComponentModel.ISupportInitialize).EndInit()
        CType(race1, ComponentModel.ISupportInitialize).EndInit()
        CType(race3, ComponentModel.ISupportInitialize).EndInit()
        CType(car, ComponentModel.ISupportInitialize).EndInit()
        CType(exp, ComponentModel.ISupportInitialize).EndInit()
        CType(powerUp1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents race2 As PictureBox
    Friend WithEvents race1 As PictureBox
    Friend WithEvents race3 As PictureBox
    Friend WithEvents car As PictureBox
    Friend WithEvents RoadMover As Timer
    Friend WithEvents RightSide As Timer
    Friend WithEvents LeftSide As Timer
    Friend WithEvents RacerMover As Timer
    Friend WithEvents RacerMover2 As Timer
    Friend WithEvents RacerMover3 As Timer
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents exp As PictureBox
    Friend WithEvents explosao As Timer
    Friend WithEvents powerUp1 As PictureBox
    Friend WithEvents powerUp As Timer
    Friend WithEvents Upside As Timer
    Friend WithEvents DownSide As Timer
    Friend WithEvents mudarDire1 As Timer
    Friend WithEvents colocarPowerUP As Timer
    Friend WithEvents powerUpAtv As Timer

End Class
