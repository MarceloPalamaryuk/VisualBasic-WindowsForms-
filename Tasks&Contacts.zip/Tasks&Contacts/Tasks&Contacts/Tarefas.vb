﻿Public Class Tarefas
    Private atualizar As Boolean = False
    Private Sub TarefaBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TarefaBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TarefaBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)

    End Sub

    Private Sub Tarefas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TipoTarefaTableAdapter.Fill(Me.TasksContactsDataSet.TipoTarefa)
        Me.TarefaTableAdapter.Fill(Me.TasksContactsDataSet.Tarefa)

        TarefaBindingSource.Filter = "User = '" & UtilizadorAtual & "'"
    End Sub

    Private Sub btn_Voltar_Click(sender As Object, e As EventArgs) Handles btn_Voltar.Click
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub btn_adicionar_Click(sender As Object, e As EventArgs) Handles btn_adicionar.Click
        atualizar = False
        txt_Nome.Clear()
        txt_Notas.Clear()
        cb_Tipo.SelectedIndex = -1

        cb_Tipo.Enabled = True
        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_crescente.Enabled = False
        btn_default.Enabled = False
        btn_guardar.Text = "Adicionar"
        gb_controls.Visible = True
    End Sub

    Private Sub btn_guardar_Click(sender As Object, e As EventArgs) Handles btn_guardar.Click
        If txt_Nome.Text = "" Or cb_Tipo.SelectedItem Is Nothing Then
            MessageBox.Show("Preencha pelo menos os campos Nome e Tipo!")
            Return
        End If
        'tipo selecionado na combobox
        Dim tipoAtual As DataRowView = TryCast(cb_Tipo.SelectedItem, DataRowView)
        Dim tarefa As DataRowView

        If atualizar Then
            'atualizar
            tarefa = CType(TarefaBindingSource.Current, DataRowView)
        Else
            'novo
            tarefa = CType(TarefaBindingSource.AddNew(), DataRowView)
            tarefa("User") = UtilizadorAtual
            tarefa("DataInicio") = DateTime.Now
            tarefa("IDTipoTarefa") = tipoAtual("IDTipoTarefa")
        End If

        tarefa("Nome") = txt_Nome.Text
        tarefa("Notas") = If(txt_Notas.Text = "", DBNull.Value, txt_Notas.Text)
        'datafim é opcional, então se não tiver checked, vai peencher com Null
        If dp_DataFim.Checked Then
            tarefa("DataFim") = dp_DataFim.Value
        Else
            tarefa("DataFim") = DBNull.Value
        End If

        TarefaBindingSource.EndEdit()
        TarefaTableAdapter.Update(Me.TasksContactsDataSet.Tarefa)
        TarefaTableAdapter.Fill(Me.TasksContactsDataSet.Tarefa)
        TarefaBindingSource.Filter = "User = '" & UtilizadorAtual & "'"

        txt_Nome.Clear()
        txt_Notas.Clear()
        cb_Tipo.SelectedIndex = -1
        dp_DataFim.Checked = False
        btn_adicionar.Enabled = True
        btn_atualizar.Enabled = True
        btn_eliminar.Enabled = True
        btn_crescente.Enabled = True
        btn_default.Enabled = True
        gb_controls.Visible = False
    End Sub

    Private Sub btn_atualizar_Click(sender As Object, e As EventArgs) Handles btn_atualizar.Click
        If TarefaBindingSource.Current Is Nothing Then
            MessageBox.Show("Selecione uma tarefa!")
            Return
        End If
        atualizar = True

        Dim tarefaAtual As DataRowView = CType(TarefaBindingSource.Current, DataRowView)

        txt_Nome.Text = tarefaAtual("Nome")
        txt_Notas.Text = If(IsDBNull(tarefaAtual("Notas")), "", tarefaAtual("Notas"))
        cb_Tipo.SelectedValue = tarefaAtual("IDTipoTarefa")
        dp_DataFim.Checked = Not IsDBNull(tarefaAtual("DataFim"))
        If dp_DataFim.Checked Then
            dp_DataFim.Value = tarefaAtual("DataFim")
        End If

        cb_Tipo.Enabled = False
        btn_guardar.Text = "Atualizar"
        gb_controls.Visible = True
        btn_adicionar.Enabled = False
        btn_eliminar.Enabled = False
        btn_crescente.Enabled = False
        btn_default.Enabled = False
    End Sub

    Private Sub btn_eliminar_Click(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        Dim tarefaAtual As DataRowView = TryCast(TarefaBindingSource.Current, DataRowView)
        If tarefaAtual Is Nothing Then
            MessageBox.Show("Selecione uma tarefa!")
            Return
        End If

        TarefaBindingSource.RemoveCurrent()
        TarefaBindingSource.EndEdit()
        TarefaTableAdapter.Update(Me.TasksContactsDataSet.Tarefa)
        TarefaBindingSource.Filter = "User = '" & UtilizadorAtual & "'"
    End Sub

    Private Sub btn_crescente_Click(sender As Object, e As EventArgs) Handles btn_crescente.Click
        TarefaBindingSource.Sort = "DataFim ASC"
    End Sub
    Private Sub btn_decrescente_Click(sender As Object, e As EventArgs) Handles btn_decrescente.Click
        TarefaBindingSource.Sort = "DataFim DESC"
    End Sub

    Private Sub btn_default_Click(sender As Object, e As EventArgs) Handles btn_default.Click
        TarefaBindingSource.Sort = ""
    End Sub
End Class