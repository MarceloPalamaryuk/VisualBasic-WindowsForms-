﻿Public Class Form2
    Private Sub UtilizadorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles UtilizadorBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UtilizadorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'cria um novo utilizador 
        UtilizadorBindingSource.AddNew()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'aqui eu so colocei a parte de guardar do video e verifica se as passwords nos dois campos são iguais
        If PassTextBox.Text = confirmar.Text Then
            Try
                Me.Validate()
                Me.UtilizadorBindingSource.EndEdit()
                Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)
                MessageBox.Show("Registo criado com sucesso!")

                Form1.UtilizadorTableAdapter.Fill(Form1.TasksContactsDataSet.Utilizador)
                Form1.UserTextBox.Text = ""
                Form1.PassTextBox.Text = ""

                Form1.Show()
                Form1.cadastrar.Hide()
                Form1.Button2.Enabled = False
            Catch ex As Exception
                UserTextBox.Clear()
                UserTextBox.Focus()
                MessageBox.Show("Utilizador já existe! Escolha outro nome!")
            End Try
        Else
            MessageBox.Show("As passwords não coecidem!")
            PassTextBox.Clear()
            confirmar.Clear()
            PassTextBox.Focus()
        End If
    End Sub
End Class