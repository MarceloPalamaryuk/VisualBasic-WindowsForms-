﻿Imports Tasks_Contacts.TasksContactsDataSetTableAdapters

Public Class TiposTarefas
    Private atualizar As Boolean = False
    Private Sub TipoTarefaBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TipoTarefaBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TipoTarefaBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)
    End Sub

    Private Sub TiposTarefas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TipoTarefaTableAdapter.Fill(Me.TasksContactsDataSet.TipoTarefa)

    End Sub

    Private Sub btn_voltar_Click(sender As Object, e As EventArgs) Handles btn_voltar.Click
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub btn_adicionar_Click(sender As Object, e As EventArgs) Handles btn_adicionar.Click
        atualizar = False
        txt_Tipo.Clear()
        txt_Valor.Clear()

        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_guardar.Text = "Adicionar"
        gb_controlo.Visible = True
    End Sub

    Private Sub btn_guardar_Click(sender As Object, e As EventArgs) Handles btn_guardar.Click
        'verifica se os campos estão preenchidos
        If (txt_Tipo.Text = "" Or txt_Valor.Text = "") Then
            MessageBox.Show("Preencha os campos!")
            Return
        End If

        Dim tipos As DataRowView

        If atualizar Then
            'atualizar
            tipos = CType(TipoTarefaBindingSource.Current, DataRowView)

            tipos("Tipo") = txt_Tipo.Text
            tipos("Valor") = txt_Valor.Text
        Else
            'adicionar
            tipos = CType(TipoTarefaBindingSource.AddNew(), DataRowView)

            tipos("Tipo") = txt_Tipo.Text
            tipos("Valor") = txt_Valor.Text
        End If

        TipoTarefaBindingSource.EndEdit()
        TipoTarefaTableAdapter.Update(Me.TasksContactsDataSet.TipoTarefa)

        TasksContactsDataSet.TipoTarefa.Clear()
        TipoTarefaTableAdapter.Fill(Me.TasksContactsDataSet.TipoTarefa)

        txt_Tipo.Clear()
        txt_Valor.Clear()
        btn_adicionar.Enabled = True
        btn_atualizar.Enabled = True
        btn_eliminar.Enabled = True

        gb_controlo.Visible = False
    End Sub

    Private Sub btn_atualizar_Click(sender As Object, e As EventArgs) Handles btn_atualizar.Click
        Dim tipoSel As DataRowView = TryCast(TipoTarefaBindingSource.Current, DataRowView)

        If tipoSel Is Nothing Then
            MessageBox.Show("Selecione um tipo primeiro")
            Return
        End If

        atualizar = True
        txt_Tipo.Text = tipoSel("Tipo").ToString()
        txt_Valor.Text = tipoSel("Valor").ToString()

        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_guardar.Text = "Atualizar"
        gb_controlo.Visible = True
    End Sub

    Private Sub btn_eliminar_Click(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        Dim tipoSel As DataRowView = TryCast(TipoTarefaBindingSource.Current, DataRowView)
        If tipoSel Is Nothing Then
            MessageBox.Show("Selecione um tipo primeiro")
            Return
        End If

        Try
            TipoTarefaBindingSource.RemoveCurrent()
            TipoTarefaBindingSource.EndEdit()
            TipoTarefaTableAdapter.Update(Me.TasksContactsDataSet.TipoTarefa)

        Catch ex As Exception
            MessageBox.Show("Tipo em uso!")
            TasksContactsDataSet.TipoTarefa.Clear()
            TipoTarefaTableAdapter.Fill(TasksContactsDataSet.TipoTarefa)
        End Try
    End Sub
End Class