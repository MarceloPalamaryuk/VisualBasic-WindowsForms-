﻿Imports System.Media

Public Class Form1
    Public cadastrar As New Form2
    Public conteudo As New Form3
    Private Sub UtilizadorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles UtilizadorBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UtilizadorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)

    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.UtilizadorTableAdapter.Fill(Me.TasksContactsDataSet.Utilizador)
        'tira os dados para o utilizador não ver
        UserTextBox.Text = ""
        PassTextBox.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'verifica se os campos estão preenchidos
        If UserTextBox.Text = "" Or PassTextBox.Text = "" Then
            MessageBox.Show("Preenche todos os campos.")
            Exit Sub
        End If

        Dim user As String = UserTextBox.Text.Replace("'", "''")
        Dim pass As String = PassTextBox.Text.Replace("'", "''")

        UtilizadorBindingSource.Filter =
        $"[User] = '{user}' AND [Pass] = '{pass}'"

        If UtilizadorBindingSource.Count = 1 Then
            'guarda os dados do utilizador atual
            Dim dados As DataRowView = CType(UtilizadorBindingSource.Current, DataRowView)

            Conta.UtilizadorAtual = dados("User").ToString()
            Conta.Pass = dados("Pass").ToString()
            MessageBox.Show("Login efetuado com sucesso!")
            conteudo.Show()
            Me.Hide()
        Else
            MessageBox.Show("Username ou password incorretos.")
            PassTextBox.Clear()
            PassTextBox.Focus()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        cadastrar.Show()
        Me.Hide()
    End Sub


End Class
