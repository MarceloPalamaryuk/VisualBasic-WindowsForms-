﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Sair
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Sair))
        Me.mudarCorBG = New System.Windows.Forms.Timer(Me.components)
        Me.timer_left = New System.Windows.Forms.Timer(Me.components)
        Me.Boss = New System.Windows.Forms.Label()
        Me.Jogador = New System.Windows.Forms.Label()
        Me.lb_boss = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.timer_right = New System.Windows.Forms.Timer(Me.components)
        Me.timer_up = New System.Windows.Forms.Timer(Me.components)
        Me.timer_down = New System.Windows.Forms.Timer(Me.components)
        Me.timer_disparo = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'mudarCorBG
        '
        Me.mudarCorBG.Interval = 200
        '
        'timer_left
        '
        Me.timer_left.Interval = 10
        '
        'Boss
        '
        Me.Boss.AutoSize = True
        Me.Boss.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Boss.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.Boss.ForeColor = System.Drawing.Color.Red
        Me.Boss.Location = New System.Drawing.Point(356, 54)
        Me.Boss.Name = "Boss"
        Me.Boss.Size = New System.Drawing.Size(78, 39)
        Me.Boss.TabIndex = 0
        Me.Boss.Text = "Sair"
        '
        'Jogador
        '
        Me.Jogador.AutoSize = True
        Me.Jogador.BackColor = System.Drawing.Color.Transparent
        Me.Jogador.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Jogador.ForeColor = System.Drawing.Color.Blue
        Me.Jogador.Location = New System.Drawing.Point(358, 284)
        Me.Jogador.Name = "Jogador"
        Me.Jogador.Size = New System.Drawing.Size(96, 29)
        Me.Jogador.TabIndex = 1
        Me.Jogador.Text = "(•_•)̸/̸̅̅ ̆̅ ̅̅ ̅̅ ̅̅"
        '
        'lb_boss
        '
        Me.lb_boss.AutoSize = True
        Me.lb_boss.BackColor = System.Drawing.Color.Transparent
        Me.lb_boss.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lb_boss.Location = New System.Drawing.Point(12, 19)
        Me.lb_boss.Name = "lb_boss"
        Me.lb_boss.Size = New System.Drawing.Size(175, 29)
        Me.lb_boss.TabIndex = 2
        Me.lb_boss.Text = "Boss: 1000HP"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label3.Location = New System.Drawing.Point(12, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(195, 29)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Jogador: 100HP"
        '
        'timer_right
        '
        Me.timer_right.Interval = 10
        '
        'timer_up
        '
        Me.timer_up.Interval = 10
        '
        'timer_down
        '
        Me.timer_down.Interval = 10
        '
        'timer_disparo
        '
        '
        'Sair
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Orange
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lb_boss)
        Me.Controls.Add(Me.Jogador)
        Me.Controls.Add(Me.Boss)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Sair"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sair? Não"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mudarCorBG As Timer
    Friend WithEvents timer_left As Timer
    Friend WithEvents Boss As Label
    Friend WithEvents Jogador As Label
    Friend WithEvents lb_boss As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents timer_right As Timer
    Friend WithEvents timer_up As Timer
    Friend WithEvents timer_down As Timer
    Friend WithEvents timer_disparo As Timer
End Class
