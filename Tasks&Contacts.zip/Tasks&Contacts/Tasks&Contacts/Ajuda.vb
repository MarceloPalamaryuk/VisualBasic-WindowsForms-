﻿Public Class Ajuda
    Private Sub Ajuda_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_Voltar_Click(sender As Object, e As EventArgs) Handles btn_Voltar.Click
        Me.Hide()
        Form3.Show()
    End Sub
End Class