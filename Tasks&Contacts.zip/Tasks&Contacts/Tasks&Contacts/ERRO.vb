﻿Public Class ERRO
    Public s As New Sair
    Private Sub inicio_Tick(sender As Object, e As EventArgs) Handles inicio.Tick
        inicio.Stop()
        Me.Hide()
        s.Show()
    End Sub

    Private Sub ERRO_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        inicio.Start()
    End Sub
End Class