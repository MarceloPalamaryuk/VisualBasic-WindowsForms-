﻿Public Class Form3
    Public contaF As New ContaForm
    Public c As New contatos
    Public tc As New TiposContatos
    Public tt As New TiposTarefas
    Public t As New Tarefas
    Public a As New Ajuda
    Public er As New ERRO
    Private Sub SairToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SairToolStripMenuItem.Click
        Me.Hide()
        er.Show()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = $"Bem vindo {Conta.UtilizadorAtual}!"
    End Sub

    Private Sub ContaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContaToolStripMenuItem.Click
        contaF.Show()
        Me.Hide()
    End Sub

    Private Sub ContatosToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ContatosToolStripMenuItem1.Click
        Me.Hide()
        c.Show()
    End Sub

    Private Sub TipoContatosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TipoContatosToolStripMenuItem.Click
        Me.Hide()
        tc.Show()
    End Sub

    Private Sub TiposToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TiposToolStripMenuItem.Click
        Me.Hide()
        tt.Show()
    End Sub

    Private Sub TarefasToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles TarefasToolStripMenuItem1.Click
        Me.Hide()
        t.Show()
    End Sub

    Private Sub AjudaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AjudaToolStripMenuItem.Click
        Me.Hide()
        a.Show()
    End Sub
End Class