﻿Public Class Sair
    'a maioria do codigo é chatgpt
    Private rainbowColors As Color() = {
        Color.LightPink,
        Color.LightSalmon,
        Color.LightYellow,
        Color.LightGreen,
        Color.LightSkyBlue,
        Color.LightBlue,
        Color.Plum
    }
    Private rainbowIndex As Integer = 0

    Private tiros As New List(Of Label)
    Private tiroVelocidade As Integer = 10


    Private mouseX As Integer
    Private mouseY As Integer
    Private bossHP As Integer = 1000
    Private jogadorHP As Integer = 100
    Private imunity = 2000 '2 segundos
    Private dano = 10

    Private bossTeleportTimer As New Timer
    Private bossAttackTimer As New Timer
    Private rand As New Random()

    Private jogadorImune As Boolean = False
    Private imunityTimer As New Timer

    Private Sub Sair_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bossTeleportTimer.Interval = 3000 ' 3 segundos
        AddHandler bossTeleportTimer.Tick, AddressOf TeleportarBoss
        bossTeleportTimer.Start()

        bossAttackTimer.Interval = 2000
        AddHandler bossAttackTimer.Tick, AddressOf BossAtacar
        bossAttackTimer.Start()

        imunityTimer.Interval = imunity
        AddHandler imunityTimer.Tick, Sub()
                                          jogadorImune = False
                                          imunityTimer.Stop()
                                      End Sub
    End Sub

    Private Sub mudarCorBG_Tick(sender As Object, e As EventArgs) Handles mudarCorBG.Tick
        Me.BackColor = rainbowColors(rainbowIndex)
        rainbowIndex += 1
        If rainbowIndex >= rainbowColors.Length Then
            rainbowIndex = 0
        End If
    End Sub

    Private Sub Sair_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Left Then timer_left.Start()
        If e.KeyCode = Keys.Right Then timer_right.Start()
        If e.KeyCode = Keys.Up Then timer_up.Start()
        If e.KeyCode = Keys.Down Then timer_down.Start()
    End Sub

    Private Sub timer_left_Tick(sender As Object, e As EventArgs) Handles timer_left.Tick
        Jogador.Left -= 5
        If Jogador.Left < 0 Then Jogador.Left = 0
    End Sub

    Private Sub timer_right_Tick(sender As Object, e As EventArgs) Handles timer_right.Tick
        Jogador.Left += 5
        If Jogador.Right > Me.ClientSize.Width Then Jogador.Left = Me.ClientSize.Width - Jogador.Width
    End Sub

    Private Sub timer_up_Tick(sender As Object, e As EventArgs) Handles timer_up.Tick
        Jogador.Top -= 5
        If Jogador.Top < 0 Then Jogador.Top = 0
    End Sub

    Private Sub timer_down_Tick(sender As Object, e As EventArgs) Handles timer_down.Tick
        Jogador.Top += 5
        If Jogador.Bottom > Me.ClientSize.Height Then Jogador.Top = Me.ClientSize.Height - Jogador.Height
    End Sub

    Private Sub Sair_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        If e.KeyCode = Keys.Left Then
            timer_left.Stop()
        End If
        If e.KeyCode = Keys.Right Then
            timer_right.Stop()
        End If
        If e.KeyCode = Keys.Down Then
            timer_down.Stop()
        End If
        If e.KeyCode = Keys.Up Then
            timer_up.Stop()
        End If
    End Sub

    Private Sub Label3_MouseMove(sender As Object, e As MouseEventArgs) Handles Label3.MouseMove
        mouseX = e.X
        mouseY = e.Y
    End Sub

    Private Sub DispararTiro(destinoX As Integer, destinoY As Integer)
        Dim tiro As New Label
        tiro.BackColor = Color.Yellow
        tiro.Size = New Size(5, 5)
        tiro.Left = Jogador.Left + Jogador.Width \ 2 - tiro.Width \ 2
        tiro.Top = Jogador.Top + Jogador.Height \ 2 - tiro.Height \ 2
        Me.Controls.Add(tiro)
        tiros.Add(tiro)

        ' Calcula vetor direção normalizado
        Dim dx As Single = destinoX - (tiro.Left + tiro.Width / 2)
        Dim dy As Single = destinoY - (tiro.Top + tiro.Height / 2)
        Dim comprimento As Single = Math.Sqrt(dx * dx + dy * dy)
        Dim dirX As Single = dx / comprimento
        Dim dirY As Single = dy / comprimento

        ' Timer para mover o tiro
        Dim tmr As New Timer
        tmr.Interval = 20
        AddHandler tmr.Tick, Sub(senderT, eT)
                                 tiro.Left += CInt(dirX * tiroVelocidade)
                                 tiro.Top += CInt(dirY * tiroVelocidade)

                                 ' Verifica colisão com o Boss
                                 If tiro.Bounds.IntersectsWith(Boss.Bounds) Then

                                     If bossHP <= 0 Then
                                         Me.Close()
                                         Application.Exit()
                                     Else
                                         bossHP -= 10
                                         lb_boss.Text = "Boss: " & bossHP & "HP"
                                     End If

                                     ' Remove o tiro
                                     Me.Controls.Remove(tiro)
                                     tiros.Remove(tiro)
                                     tmr.Stop()
                                     tmr.Dispose()
                                     Return
                                 End If

                                 ' Remove se sair da tela
                                 If tiro.Top + tiro.Height < 0 OrElse tiro.Top > Me.ClientSize.Height _
        OrElse tiro.Left + tiro.Width < 0 OrElse tiro.Left > Me.ClientSize.Width Then
                                     Me.Controls.Remove(tiro)
                                     tiros.Remove(tiro)
                                     tmr.Stop()
                                     tmr.Dispose()
                                 End If
                             End Sub

        tmr.Start()
    End Sub

    Private Sub Sair_MouseDown(sender As Object, e As MouseEventArgs) Handles MyBase.MouseDown
        If e.Button = MouseButtons.Left Then
            timer_disparo.Start()
        End If
    End Sub

    Private Sub Sair_MouseUp(sender As Object, e As MouseEventArgs) Handles MyBase.MouseUp
        If e.Button = MouseButtons.Left Then
            timer_disparo.Stop()
        End If
    End Sub

    Private Sub timer_disparo_Tick(sender As Object, e As EventArgs) Handles timer_disparo.Tick
        Dim mousePos As Point = Me.PointToClient(Cursor.Position)
        DispararTiro(mousePos.X, mousePos.Y)
    End Sub

    Private Sub TeleportarBoss(sender As Object, e As EventArgs)
        ' Garante que o boss cabe no form
        If Boss.Width >= Me.ClientSize.Width OrElse Boss.Height >= Me.ClientSize.Height Then
            Exit Sub
        End If

        Dim maxX As Integer = Me.ClientSize.Width - Boss.Width
        Dim maxY As Integer = Me.ClientSize.Height - Boss.Height

        Dim x As Integer = rand.Next(0, maxX + 1)
        Dim y As Integer = rand.Next(0, maxY + 1)

        Boss.Left = x
        Boss.Top = y

        ' Segunda fase
        If bossHP <= 650 Then
            bossTeleportTimer.Interval = 1500
            Boss.BackColor = Color.Red
            Boss.ForeColor = Color.Transparent
            Label3.ForeColor = Color.Red
            lb_boss.ForeColor = Color.Red
            mudarCorBG.Start()
        End If
    End Sub

    Private Sub DispararTiroBoss(dirX As Single, dirY As Single, tamanho As Integer, cor As Color)
        Dim tiro As New Label
        tiro.Size = New Size(tamanho, tamanho)
        tiro.BackColor = cor
        tiro.Left = Boss.Left + Boss.Width \ 2
        tiro.Top = Boss.Top + Boss.Height \ 2
        Me.Controls.Add(tiro)

        Dim tmr As New Timer
        tmr.Interval = 30 ' lento
        AddHandler tmr.Tick, Sub()
                                 tiro.Left += CInt(dirX * 6)
                                 tiro.Top += CInt(dirY * 6)

                                 ' Colisão com jogador
                                 If tiro.Bounds.IntersectsWith(Jogador.Bounds) AndAlso Not jogadorImune Then
                                     jogadorHP -= dano
                                     Label3.Text = "Player: " & jogadorHP & "HP"

                                     jogadorImune = True
                                     imunityTimer.Start()

                                     Me.Controls.Remove(tiro)
                                     tmr.Stop()
                                     tmr.Dispose()
                                     Return
                                 End If

                                 ' Fora da tela
                                 If tiro.Left < 0 OrElse tiro.Top < 0 OrElse
                                    tiro.Left > Me.ClientSize.Width OrElse tiro.Top > Me.ClientSize.Height Then
                                     Me.Controls.Remove(tiro)
                                     tmr.Stop()
                                     tmr.Dispose()
                                 End If
                             End Sub
        tmr.Start()
    End Sub

    Private Async Sub Ataque1()
        For i As Integer = 1 To 5
            Dim dx As Single = Jogador.Left - Boss.Left
            Dim dy As Single = Jogador.Top - Boss.Top
            Dim len As Single = Math.Sqrt(dx * dx + dy * dy)

            DispararTiroBoss(dx / len, dy / len, 10, Color.Red)
            Await Task.Delay(300)
        Next
    End Sub

    Private Sub Ataque2()
        Dim dx As Single = Jogador.Left - Boss.Left
        Dim dy As Single = Jogador.Top - Boss.Top
        Dim len As Single = Math.Sqrt(dx * dx + dy * dy)

        Dim baseX As Single = dx / len
        Dim baseY As Single = dy / len

        Dim angulo As Double = Math.PI / 6 ' 30 graus

        ' centro
        DispararTiroBoss(baseX, baseY, 7, Color.Blue)

        ' esquerda
        DispararTiroBoss(
            CSng(baseX * Math.Cos(angulo) - baseY * Math.Sin(angulo)),
            CSng(baseX * Math.Sin(angulo) + baseY * Math.Cos(angulo)),
            7, Color.Blue)

        ' direita
        DispararTiroBoss(
            CSng(baseX * Math.Cos(-angulo) - baseY * Math.Sin(-angulo)),
            CSng(baseX * Math.Sin(-angulo) + baseY * Math.Cos(-angulo)),
            7, Color.Blue)
    End Sub

    Private Sub BossAtacar(sender As Object, e As EventArgs)
        If rand.Next(0, 2) = 0 Then
            Ataque1()
        Else
            Ataque2()
        End If
    End Sub
End Class