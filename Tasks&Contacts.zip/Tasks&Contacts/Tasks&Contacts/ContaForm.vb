﻿Public Class ContaForm
    Private dados As DataRowView
    Private Sub UtilizadorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles UtilizadorBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UtilizadorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)

    End Sub

    Private Sub ContaForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta linha de código carrega dados na tabela 'TasksContactsDataSet.Utilizador'. Você pode movê-la ou removê-la conforme necessário.
        Me.UtilizadorTableAdapter.Fill(Me.TasksContactsDataSet.Utilizador)

        UtilizadorBindingSource.Filter = "User = '" & UtilizadorAtual & "'"
        dados = CType(UtilizadorBindingSource.Current, DataRowView)

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If (PassTextBox.PasswordChar = "*") Then
            PassTextBox.PasswordChar = ""
        Else
            PassTextBox.PasswordChar = "*"
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Me.Validate()
            UtilizadorBindingSource.EndEdit()
            TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)

            UtilizadorAtual = dados("User").ToString()
            Pass = dados("Pass").ToString()

            MessageBox.Show("Dados guardados com sucesso!")
            Form3.Show()
            Form3.Label1.Text = "Bem vindo " & UtilizadorAtual & "!"
            Me.Hide()
        Catch ex As Exception
            MessageBox.Show("Erro ao guardar os dados: " & ex.Message)
        End Try
    End Sub
End Class