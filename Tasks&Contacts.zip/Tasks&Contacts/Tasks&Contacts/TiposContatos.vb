﻿Public Class TiposContatos
    Private atualizar As Boolean = False
    Private Sub TiposContatos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ContatoTableAdapter.Fill(Me.TasksContactsDataSet.Contato)
        Me.TipoContatoTableAdapter.Fill(Me.TasksContactsDataSet.TipoContato)

        'filtrar a datagrid, começa por filtrar os contatos do utilizador
        ContatoBindingSource.Filter = "User = '" & UtilizadorAtual & "'"

        'criar uma lista
        Dim ids As New List(Of String)

        'coloca o id dos contatos filtrados na lista
        For Each drv As DataRowView In ContatoBindingSource
            ids.Add(drv("IDCon").ToString())
        Next

        'filtro final. Se o utilizador tiver contatos, mostra os tipos relacionados
        If ids.Count > 0 Then
            'o "String.Join(",", ids) separa os ids por virgulas"
            TipoContatoBindingSource.Filter = "IDCon IN (" & String.Join(",", ids) & ")"
        Else
            'mostra a grid vazia se o utilizador não tiver tipos
            TipoContatoBindingSource.Filter = "IDCon = -1"
        End If

        cb_Contato.DataSource = ContatoBindingSource
        cb_Contato.DisplayMember = "Nome"
        cb_Contato.ValueMember = "IDCon"
    End Sub

    Private Sub TipoContatoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TipoContatoBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TipoContatoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)
    End Sub

    Private Sub Btn_voltar_Click(sender As Object, e As EventArgs) Handles btn_voltar.Click
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub Btn_adicionar_Click(sender As Object, e As EventArgs) Handles btn_adicionar.Click
        atualizar = False
        txt_Tipo.Clear()
        txt_Valor.Clear()


        cb_Contato.SelectedIndex = -1
        cb_Contato.Enabled = True

        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_guardar.Text = "Adicionar"
        gb_control.Visible = True
    End Sub

    Private Sub Btn_guardar_Click(sender As Object, e As EventArgs) Handles btn_guardar.Click
        'verifica se as caixas estão preenchidas
        If txt_Tipo.Text = "" Or txt_Valor.Text = "" Or cb_Contato.SelectedItem Is Nothing Then
            MessageBox.Show("Preencha todos os campos")
            Return
        End If
        'coloca o id do contato selecionado em "contatoAtual"
        Dim contatoAtual As DataRowView = TryCast(cb_Contato.SelectedItem, DataRowView)
        Dim tipoContato As DataRowView

        If atualizar Then
            'atualizar
            tipoContato = CType(TipoContatoBindingSource.Current, DataRowView)
        Else
            'novo
            tipoContato = CType(TipoContatoBindingSource.AddNew(), DataRowView)
            tipoContato("IDCon") = contatoAtual("IDCon")
        End If

        tipoContato("Tipo") = txt_Tipo.Text
        tipoContato("Valor") = txt_Valor.Text

        TipoContatoBindingSource.EndEdit()
        TipoContatoTableAdapter.Update(Me.TasksContactsDataSet.TipoContato)
        TipoContatoTableAdapter.Fill(Me.TasksContactsDataSet.TipoContato)

        txt_Tipo.Clear()
        txt_Valor.Clear()
        btn_adicionar.Enabled = True
        btn_atualizar.Enabled = True
        btn_eliminar.Enabled = True
        gb_control.Visible = False

        'reseta a tabela para ter o novo valor quando for para adicionar
        TipoContatoBindingSource.ResetBindings(False)

        'reaplicar o filtro que fiz no inicio
        Dim ids As New List(Of String)
        For Each drv As DataRowView In ContatoBindingSource
            ids.Add(drv("IDCon").ToString())
        Next

        If ids.Count > 0 Then
            TipoContatoBindingSource.Filter = "IDCon IN (" & String.Join(",", ids) & ")"
        Else
            TipoContatoBindingSource.Filter = "IDCon = -1"
        End If
    End Sub

    Private Sub btn_atualizar_Click(sender As Object, e As EventArgs) Handles btn_atualizar.Click
        've se o utilizador selecionou um registro
        If TipoContatoBindingSource.Current Is Nothing Then
            MessageBox.Show("Selecione um registo")
            Return
        End If

        Dim tipoContato As DataRowView = CType(TipoContatoBindingSource.Current, DataRowView)

        txt_Tipo.Text = tipoContato("Tipo").ToString()
        txt_Valor.Text = tipoContato("Valor").ToString()

        cb_Contato.SelectedValue = tipoContato("IDCon")
        cb_Contato.Enabled = False
        atualizar = True
        btn_guardar.Text = "Atualizar"
        gb_control.Visible = True

        btn_adicionar.Enabled = False
        btn_eliminar.Enabled = False
    End Sub

    Private Sub btn_eliminar_Click(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        Dim atualC As DataRowView = TryCast(TipoContatoBindingSource.Current, DataRowView)
        If atualC Is Nothing Then
            MessageBox.Show("Selecione um tipo para eliminar")
            Return
        End If
        TipoContatoBindingSource.RemoveCurrent()
        TipoContatoBindingSource.EndEdit()
        TipoContatoTableAdapter.Update(Me.TasksContactsDataSet.TipoContato)
    End Sub

    Private Sub TiposContatos_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        'reaplicar o filtor cada vez que o utilizador reabre o form
        ContatoTableAdapter.Fill(TasksContactsDataSet.Contato)
        ContatoBindingSource.Filter = "User = '" & UtilizadorAtual & "'"
        TipoContatoTableAdapter.Fill(TasksContactsDataSet.TipoContato)
        Dim ids As New List(Of String)
        For Each drv As DataRowView In ContatoBindingSource
            ids.Add(drv("IDCon").ToString())
        Next
        If ids.Count > 0 Then
            TipoContatoBindingSource.Filter = "IDCon IN (" & String.Join(",", ids) & ")"
        Else
            TipoContatoBindingSource.Filter = "IDCon = -1"
        End If
        TipoContatoBindingSource.ResetBindings(False)
    End Sub
End Class