﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tarefas
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Tarefas))
        Me.TasksContactsDataSet = New Tasks_Contacts.TasksContactsDataSet()
        Me.TarefaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TarefaTableAdapter = New Tasks_Contacts.TasksContactsDataSetTableAdapters.TarefaTableAdapter()
        Me.TableAdapterManager = New Tasks_Contacts.TasksContactsDataSetTableAdapters.TableAdapterManager()
        Me.TarefaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TarefaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TarefaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.btn_Voltar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Nome = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Notas = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dp_DataFim = New System.Windows.Forms.DateTimePicker()
        Me.TipoTarefaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TipoTarefaTableAdapter = New Tasks_Contacts.TasksContactsDataSetTableAdapters.TipoTarefaTableAdapter()
        Me.cb_Tipo = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.gb_controls = New System.Windows.Forms.GroupBox()
        Me.btn_guardar = New System.Windows.Forms.Button()
        Me.btn_atualizar = New System.Windows.Forms.Button()
        Me.btn_eliminar = New System.Windows.Forms.Button()
        Me.btn_adicionar = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btn_crescente = New System.Windows.Forms.Button()
        Me.btn_default = New System.Windows.Forms.Button()
        Me.TipoTarefaTarefaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btn_decrescente = New System.Windows.Forms.Button()
        CType(Me.TasksContactsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TarefaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TarefaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TarefaBindingNavigator.SuspendLayout()
        CType(Me.TarefaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TipoTarefaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_controls.SuspendLayout()
        CType(Me.TipoTarefaTarefaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TasksContactsDataSet
        '
        Me.TasksContactsDataSet.DataSetName = "TasksContactsDataSet"
        Me.TasksContactsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TarefaBindingSource
        '
        Me.TarefaBindingSource.DataMember = "Tarefa"
        Me.TarefaBindingSource.DataSource = Me.TasksContactsDataSet
        '
        'TarefaTableAdapter
        '
        Me.TarefaTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContatoTableAdapter = Nothing
        Me.TableAdapterManager.TarefaTableAdapter = Me.TarefaTableAdapter
        Me.TableAdapterManager.TipoContatoTableAdapter = Nothing
        Me.TableAdapterManager.TipoTarefaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Tasks_Contacts.TasksContactsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UtilizadorTableAdapter = Nothing
        '
        'TarefaBindingNavigator
        '
        Me.TarefaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TarefaBindingNavigator.BindingSource = Me.TarefaBindingSource
        Me.TarefaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TarefaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TarefaBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.TarefaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TarefaBindingNavigatorSaveItem})
        Me.TarefaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TarefaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TarefaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TarefaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TarefaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TarefaBindingNavigator.Name = "TarefaBindingNavigator"
        Me.TarefaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TarefaBindingNavigator.Size = New System.Drawing.Size(800, 27)
        Me.TarefaBindingNavigator.TabIndex = 0
        Me.TarefaBindingNavigator.Text = "BindingNavigator1"
        Me.TarefaBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorAddNewItem.Text = "Adicionar novo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(48, 24)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de itens"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primeiro"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posição"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posição actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Mover seguinte"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'TarefaBindingNavigatorSaveItem
        '
        Me.TarefaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TarefaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TarefaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TarefaBindingNavigatorSaveItem.Name = "TarefaBindingNavigatorSaveItem"
        Me.TarefaBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 24)
        Me.TarefaBindingNavigatorSaveItem.Text = "Salvar Dados"
        '
        'TarefaDataGridView
        '
        Me.TarefaDataGridView.AutoGenerateColumns = False
        Me.TarefaDataGridView.BackgroundColor = System.Drawing.Color.LightCoral
        Me.TarefaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TarefaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.TarefaDataGridView.DataSource = Me.TarefaBindingSource
        Me.TarefaDataGridView.Location = New System.Drawing.Point(-30, 36)
        Me.TarefaDataGridView.Name = "TarefaDataGridView"
        Me.TarefaDataGridView.RowHeadersWidth = 51
        Me.TarefaDataGridView.RowTemplate.Height = 24
        Me.TarefaDataGridView.Size = New System.Drawing.Size(818, 217)
        Me.TarefaDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Nome"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Nome"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "IDTarefa"
        Me.DataGridViewTextBoxColumn2.HeaderText = "IDTarefa"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Visible = False
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Notas"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Notas"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "IDTipoTarefa"
        Me.DataGridViewTextBoxColumn4.HeaderText = "IDTipoTarefa"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "DataInicio"
        Me.DataGridViewTextBoxColumn5.HeaderText = "DataInicio"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "DataFim"
        Me.DataGridViewTextBoxColumn6.HeaderText = "DataFim"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "User"
        Me.DataGridViewTextBoxColumn7.HeaderText = "User"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Visible = False
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.DarkOrange
        Me.PictureBox1.Location = New System.Drawing.Point(0, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(803, 35)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.DarkOrange
        Me.PictureBox2.Location = New System.Drawing.Point(0, 36)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(25, 246)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.DarkOrange
        Me.PictureBox3.Location = New System.Drawing.Point(773, 36)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(30, 249)
        Me.PictureBox3.TabIndex = 4
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.DarkOrange
        Me.PictureBox4.Location = New System.Drawing.Point(0, 250)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(803, 35)
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        '
        'btn_Voltar
        '
        Me.btn_Voltar.BackColor = System.Drawing.Color.Gold
        Me.btn_Voltar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.btn_Voltar.Location = New System.Drawing.Point(647, 247)
        Me.btn_Voltar.Name = "btn_Voltar"
        Me.btn_Voltar.Size = New System.Drawing.Size(109, 38)
        Me.btn_Voltar.TabIndex = 6
        Me.btn_Voltar.Text = "Voltar"
        Me.btn_Voltar.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!)
        Me.Label1.Location = New System.Drawing.Point(332, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 33)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Tarefas"
        '
        'txt_Nome
        '
        Me.txt_Nome.BackColor = System.Drawing.Color.Gold
        Me.txt_Nome.Location = New System.Drawing.Point(8, 38)
        Me.txt_Nome.Name = "txt_Nome"
        Me.txt_Nome.Size = New System.Drawing.Size(211, 22)
        Me.txt_Nome.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.DarkOrange
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label3.Location = New System.Drawing.Point(12, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 26)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Nome"
        '
        'txt_Notas
        '
        Me.txt_Notas.BackColor = System.Drawing.Color.Gold
        Me.txt_Notas.Location = New System.Drawing.Point(8, 92)
        Me.txt_Notas.Name = "txt_Notas"
        Me.txt_Notas.Size = New System.Drawing.Size(211, 22)
        Me.txt_Notas.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkOrange
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label2.Location = New System.Drawing.Point(12, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 26)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Notas"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.DarkOrange
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label4.Location = New System.Drawing.Point(236, 63)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 26)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "DataFim"
        '
        'dp_DataFim
        '
        Me.dp_DataFim.CalendarMonthBackground = System.Drawing.Color.Gold
        Me.dp_DataFim.CalendarTitleBackColor = System.Drawing.Color.Gold
        Me.dp_DataFim.Location = New System.Drawing.Point(241, 92)
        Me.dp_DataFim.Name = "dp_DataFim"
        Me.dp_DataFim.ShowCheckBox = True
        Me.dp_DataFim.Size = New System.Drawing.Size(194, 22)
        Me.dp_DataFim.TabIndex = 17
        '
        'TipoTarefaBindingSource
        '
        Me.TipoTarefaBindingSource.DataMember = "TipoTarefa"
        Me.TipoTarefaBindingSource.DataSource = Me.TasksContactsDataSet
        '
        'TipoTarefaTableAdapter
        '
        Me.TipoTarefaTableAdapter.ClearBeforeFill = True
        '
        'cb_Tipo
        '
        Me.cb_Tipo.BackColor = System.Drawing.Color.Gold
        Me.cb_Tipo.DataSource = Me.TipoTarefaBindingSource
        Me.cb_Tipo.DisplayMember = "Tipo"
        Me.cb_Tipo.FormattingEnabled = True
        Me.cb_Tipo.Location = New System.Drawing.Point(241, 36)
        Me.cb_Tipo.Name = "cb_Tipo"
        Me.cb_Tipo.Size = New System.Drawing.Size(194, 24)
        Me.cb_Tipo.TabIndex = 18
        Me.cb_Tipo.ValueMember = "IDTipoTarefa"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.DarkOrange
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label5.Location = New System.Drawing.Point(236, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 26)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Tipo"
        '
        'gb_controls
        '
        Me.gb_controls.BackColor = System.Drawing.Color.DarkOrange
        Me.gb_controls.Controls.Add(Me.btn_guardar)
        Me.gb_controls.Controls.Add(Me.Label5)
        Me.gb_controls.Controls.Add(Me.cb_Tipo)
        Me.gb_controls.Controls.Add(Me.dp_DataFim)
        Me.gb_controls.Controls.Add(Me.Label4)
        Me.gb_controls.Controls.Add(Me.txt_Notas)
        Me.gb_controls.Controls.Add(Me.Label2)
        Me.gb_controls.Controls.Add(Me.txt_Nome)
        Me.gb_controls.Controls.Add(Me.Label3)
        Me.gb_controls.Location = New System.Drawing.Point(201, 307)
        Me.gb_controls.Name = "gb_controls"
        Me.gb_controls.Size = New System.Drawing.Size(569, 130)
        Me.gb_controls.TabIndex = 20
        Me.gb_controls.TabStop = False
        Me.gb_controls.Visible = False
        '
        'btn_guardar
        '
        Me.btn_guardar.BackColor = System.Drawing.Color.OrangeRed
        Me.btn_guardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold)
        Me.btn_guardar.Location = New System.Drawing.Point(441, 9)
        Me.btn_guardar.Name = "btn_guardar"
        Me.btn_guardar.Size = New System.Drawing.Size(122, 121)
        Me.btn_guardar.TabIndex = 29
        Me.btn_guardar.Text = "Adicionar"
        Me.btn_guardar.UseVisualStyleBackColor = False
        '
        'btn_atualizar
        '
        Me.btn_atualizar.BackColor = System.Drawing.Color.Orange
        Me.btn_atualizar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_atualizar.Location = New System.Drawing.Point(234, 249)
        Me.btn_atualizar.Name = "btn_atualizar"
        Me.btn_atualizar.Size = New System.Drawing.Size(181, 36)
        Me.btn_atualizar.TabIndex = 25
        Me.btn_atualizar.Text = "Atualizar Tarefa"
        Me.btn_atualizar.UseVisualStyleBackColor = False
        '
        'btn_eliminar
        '
        Me.btn_eliminar.BackColor = System.Drawing.Color.Red
        Me.btn_eliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_eliminar.ForeColor = System.Drawing.SystemColors.Control
        Me.btn_eliminar.Location = New System.Drawing.Point(442, 249)
        Me.btn_eliminar.Name = "btn_eliminar"
        Me.btn_eliminar.Size = New System.Drawing.Size(180, 36)
        Me.btn_eliminar.TabIndex = 24
        Me.btn_eliminar.Text = "Eliminar Tarefa"
        Me.btn_eliminar.UseVisualStyleBackColor = False
        '
        'btn_adicionar
        '
        Me.btn_adicionar.BackColor = System.Drawing.Color.Gold
        Me.btn_adicionar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btn_adicionar.Location = New System.Drawing.Point(31, 250)
        Me.btn_adicionar.Name = "btn_adicionar"
        Me.btn_adicionar.Size = New System.Drawing.Size(180, 36)
        Me.btn_adicionar.TabIndex = 21
        Me.btn_adicionar.Text = "Adicionar Tarefa"
        Me.btn_adicionar.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.DarkOrange
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label6.Location = New System.Drawing.Point(26, 306)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(153, 26)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Filtros de Data"
        '
        'btn_crescente
        '
        Me.btn_crescente.BackColor = System.Drawing.Color.PeachPuff
        Me.btn_crescente.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_crescente.Location = New System.Drawing.Point(12, 335)
        Me.btn_crescente.Name = "btn_crescente"
        Me.btn_crescente.Size = New System.Drawing.Size(178, 36)
        Me.btn_crescente.TabIndex = 27
        Me.btn_crescente.Text = "Tarefas a fazer"
        Me.btn_crescente.UseVisualStyleBackColor = False
        '
        'btn_default
        '
        Me.btn_default.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.btn_default.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_default.Location = New System.Drawing.Point(14, 416)
        Me.btn_default.Name = "btn_default"
        Me.btn_default.Size = New System.Drawing.Size(176, 36)
        Me.btn_default.TabIndex = 28
        Me.btn_default.Text = "Default"
        Me.btn_default.UseVisualStyleBackColor = False
        '
        'TipoTarefaTarefaBindingSource
        '
        Me.TipoTarefaTarefaBindingSource.DataMember = "TipoTarefaTarefa"
        Me.TipoTarefaTarefaBindingSource.DataSource = Me.TipoTarefaBindingSource
        '
        'btn_decrescente
        '
        Me.btn_decrescente.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_decrescente.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btn_decrescente.Location = New System.Drawing.Point(12, 374)
        Me.btn_decrescente.Name = "btn_decrescente"
        Me.btn_decrescente.Size = New System.Drawing.Size(178, 36)
        Me.btn_decrescente.TabIndex = 29
        Me.btn_decrescente.Text = "Tarefas Recentes"
        Me.btn_decrescente.UseVisualStyleBackColor = False
        '
        'Tarefas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Orange
        Me.ClientSize = New System.Drawing.Size(802, 458)
        Me.Controls.Add(Me.btn_decrescente)
        Me.Controls.Add(Me.btn_default)
        Me.Controls.Add(Me.btn_crescente)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btn_atualizar)
        Me.Controls.Add(Me.btn_eliminar)
        Me.Controls.Add(Me.btn_adicionar)
        Me.Controls.Add(Me.gb_controls)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_Voltar)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TarefaDataGridView)
        Me.Controls.Add(Me.TarefaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Tarefas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Contacts++Task"
        CType(Me.TasksContactsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TarefaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TarefaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TarefaBindingNavigator.ResumeLayout(False)
        Me.TarefaBindingNavigator.PerformLayout()
        CType(Me.TarefaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TipoTarefaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_controls.ResumeLayout(False)
        Me.gb_controls.PerformLayout()
        CType(Me.TipoTarefaTarefaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TasksContactsDataSet As TasksContactsDataSet
    Friend WithEvents TarefaBindingSource As BindingSource
    Friend WithEvents TarefaTableAdapter As TasksContactsDataSetTableAdapters.TarefaTableAdapter
    Friend WithEvents TableAdapterManager As TasksContactsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TarefaBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents TarefaBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents TarefaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btn_Voltar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_Nome As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_Notas As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents dp_DataFim As DateTimePicker
    Friend WithEvents TipoTarefaBindingSource As BindingSource
    Friend WithEvents TipoTarefaTableAdapter As TasksContactsDataSetTableAdapters.TipoTarefaTableAdapter
    Friend WithEvents cb_Tipo As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents gb_controls As GroupBox
    Friend WithEvents btn_atualizar As Button
    Friend WithEvents btn_eliminar As Button
    Friend WithEvents btn_adicionar As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents btn_crescente As Button
    Friend WithEvents btn_default As Button
    Friend WithEvents btn_guardar As Button
    Friend WithEvents TipoTarefaTarefaBindingSource As BindingSource
    Friend WithEvents btn_decrescente As Button
End Class
