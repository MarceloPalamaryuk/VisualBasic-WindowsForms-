﻿Public Class contatos
    'variavel para definir se o utilizador quer adicionar ou atualizar
    Private atualizar As Boolean = False
    Private Sub ContatoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ContatoBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ContatoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.TasksContactsDataSet)
    End Sub

    Private Sub contatos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TipoContatoTableAdapter.Fill(Me.TasksContactsDataSet.TipoContato)
        Me.ContatoTableAdapter.Fill(Me.TasksContactsDataSet.Contato)
        ContatoBindingSource.Filter = "User = '" & UtilizadorAtual & "'"

        TipoContatoBindingSource.DataSource = ContatoBindingSource
        TipoContatoBindingSource.DataMember = "ContatoTipoContato"
    End Sub

    Private Sub btn_Voltar_Click(sender As Object, e As EventArgs) Handles btn_Voltar.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub btn_adicionar_Click(sender As Object, e As EventArgs) Handles btn_adicionar.Click
        atualizar = False
        txt_Nome.Clear()
        txt_Apelido.Clear()
        rtxt_Notas.Clear()

        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_guardar.Text = "Adicionar"
        GB_Adicionar.Visible = True
    End Sub

    Private Sub btn_guardar_Click(sender As Object, e As EventArgs) Handles btn_guardar.Click
        'verifica se esta vazio
        If txt_Nome.Text = "" Or txt_Apelido.Text = "" Then
            MessageBox.Show("Preencha pelo menos os campos 'Nome' e 'Apelido'!")
            Return
        End If

        Dim contato As DataRowView

        If atualizar Then
            'atualizar
            contato = CType(ContatoBindingSource.Current, DataRowView)

            contato("Nome") = txt_Nome.Text
            contato("Apelido") = txt_Apelido.Text
            contato("Notas") = rtxt_Notas.Text
        Else
            'adicionar
            contato = CType(ContatoBindingSource.AddNew(), DataRowView)

            contato("Nome") = txt_Nome.Text
            contato("Apelido") = txt_Apelido.Text
            contato("Notas") = rtxt_Notas.Text
            'automatico
            contato("DataCriação") = DateTime.Now
            contato("User") = UtilizadorAtual
        End If

        ContatoBindingSource.EndEdit()
        ContatoTableAdapter.Update(Me.TasksContactsDataSet.Contato)

        TasksContactsDataSet.Contato.Clear()
        ContatoTableAdapter.Fill(Me.TasksContactsDataSet.Contato)
        ContatoBindingSource.Filter = "User = '" & UtilizadorAtual & "'"

        txt_Nome.Clear()
        txt_Apelido.Clear()
        rtxt_Notas.Clear()
        btn_adicionar.Enabled = True
        btn_atualizar.Enabled = True
        btn_eliminar.Enabled = True

        GB_Adicionar.Visible = False
    End Sub

    Private Sub btn_atualizar_Click(sender As Object, e As EventArgs) Handles btn_atualizar.Click
        Dim contatoSel As DataRowView = TryCast(ContatoBindingSource.Current, DataRowView)
        If contatoSel Is Nothing Then
            MessageBox.Show("Selecione um contato primeiro")
            Return
        End If

        atualizar = True
        txt_Nome.Text = contatoSel("Nome").ToString()
        txt_Apelido.Text = contatoSel("Apelido").ToString()
        rtxt_Notas.Text = contatoSel("Notas").ToString()

        btn_adicionar.Enabled = False
        btn_atualizar.Enabled = False
        btn_eliminar.Enabled = False
        btn_guardar.Text = "Atualizar"
        GB_Adicionar.Visible = True
    End Sub

    Private Sub btn_eliminar_Click_1(sender As Object, e As EventArgs) Handles btn_eliminar.Click
        'eliminar um contacto
        Dim atualC As DataRowView = TryCast(ContatoBindingSource.Current, DataRowView)

        If atualC Is Nothing Then
            MessageBox.Show("Selecione um contato para eliminar.")
            Return
        End If

        ContatoBindingSource.RemoveCurrent()
        ContatoBindingSource.EndEdit()
        ContatoTableAdapter.Update(Me.TasksContactsDataSet.Contato)
    End Sub

    Private Sub contatos_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        TasksContactsDataSet.TipoContato.Clear()
        TipoContatoTableAdapter.Fill(TasksContactsDataSet.TipoContato)
    End Sub
End Class