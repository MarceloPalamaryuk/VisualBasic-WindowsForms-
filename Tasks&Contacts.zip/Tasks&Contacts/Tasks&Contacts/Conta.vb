﻿Module Conta
    'dados do utilizador atual
    Public UtilizadorAtual As String
    Public Pass As String
End Module
