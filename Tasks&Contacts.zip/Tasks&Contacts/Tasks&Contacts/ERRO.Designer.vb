﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ERRO
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ERRO))
        Me.lb_inicio = New System.Windows.Forms.Label()
        Me.lb_inicio2 = New System.Windows.Forms.Label()
        Me.pb_inicio = New System.Windows.Forms.PictureBox()
        Me.lb_inicio3 = New System.Windows.Forms.Label()
        Me.inicio = New System.Windows.Forms.Timer(Me.components)
        CType(Me.pb_inicio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lb_inicio
        '
        Me.lb_inicio.AutoSize = True
        Me.lb_inicio.BackColor = System.Drawing.Color.Lime
        Me.lb_inicio.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!)
        Me.lb_inicio.Location = New System.Drawing.Point(69, 18)
        Me.lb_inicio.Name = "lb_inicio"
        Me.lb_inicio.Size = New System.Drawing.Size(172, 39)
        Me.lb_inicio.TabIndex = 0
        Me.lb_inicio.Text = "Controlos:"
        '
        'lb_inicio2
        '
        Me.lb_inicio2.AutoSize = True
        Me.lb_inicio2.BackColor = System.Drawing.Color.Lime
        Me.lb_inicio2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.lb_inicio2.Location = New System.Drawing.Point(23, 87)
        Me.lb_inicio2.Name = "lb_inicio2"
        Me.lb_inicio2.Size = New System.Drawing.Size(70, 26)
        Me.lb_inicio2.TabIndex = 1
        Me.lb_inicio2.Text = "Andar"
        '
        'pb_inicio
        '
        Me.pb_inicio.Image = Global.Tasks_Contacts.My.Resources.Resources.setas
        Me.pb_inicio.Location = New System.Drawing.Point(28, 136)
        Me.pb_inicio.Name = "pb_inicio"
        Me.pb_inicio.Size = New System.Drawing.Size(228, 158)
        Me.pb_inicio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb_inicio.TabIndex = 2
        Me.pb_inicio.TabStop = False
        '
        'lb_inicio3
        '
        Me.lb_inicio3.AutoSize = True
        Me.lb_inicio3.BackColor = System.Drawing.Color.Lime
        Me.lb_inicio3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.lb_inicio3.Location = New System.Drawing.Point(23, 316)
        Me.lb_inicio3.Name = "lb_inicio3"
        Me.lb_inicio3.Size = New System.Drawing.Size(279, 52)
        Me.lb_inicio3.TabIndex = 3
        Me.lb_inicio3.Text = "Dar tiro:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Segurar na posição do rato!"
        '
        'inicio
        '
        Me.inicio.Interval = 5000
        '
        'ERRO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(322, 450)
        Me.ControlBox = False
        Me.Controls.Add(Me.lb_inicio3)
        Me.Controls.Add(Me.pb_inicio)
        Me.Controls.Add(Me.lb_inicio2)
        Me.Controls.Add(Me.lb_inicio)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ERRO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "?????????????????????????????????????????????????????????????????????????????????" &
    "???????????????"
        CType(Me.pb_inicio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lb_inicio As Label
    Friend WithEvents lb_inicio2 As Label
    Friend WithEvents pb_inicio As PictureBox
    Friend WithEvents lb_inicio3 As Label
    Friend WithEvents inicio As Timer
End Class
