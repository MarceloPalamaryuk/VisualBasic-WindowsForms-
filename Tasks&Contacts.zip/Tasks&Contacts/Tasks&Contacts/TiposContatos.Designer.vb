﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TiposContatos
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TiposContatos))
        Me.TasksContactsDataSet = New Tasks_Contacts.TasksContactsDataSet()
        Me.TipoContatoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TipoContatoTableAdapter = New Tasks_Contacts.TasksContactsDataSetTableAdapters.TipoContatoTableAdapter()
        Me.TableAdapterManager = New Tasks_Contacts.TasksContactsDataSetTableAdapters.TableAdapterManager()
        Me.TipoContatoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TipoContatoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TipoContatoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btn_adicionar = New System.Windows.Forms.Button()
        Me.btn_atualizar = New System.Windows.Forms.Button()
        Me.btn_eliminar = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btn_voltar = New System.Windows.Forms.Button()
        Me.txt_Tipo = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Valor = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ContatoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ContatoTableAdapter = New Tasks_Contacts.TasksContactsDataSetTableAdapters.ContatoTableAdapter()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cb_Contato = New System.Windows.Forms.ComboBox()
        Me.btn_guardar = New System.Windows.Forms.Button()
        Me.gb_control = New System.Windows.Forms.GroupBox()
        CType(Me.TasksContactsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TipoContatoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TipoContatoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TipoContatoBindingNavigator.SuspendLayout()
        CType(Me.TipoContatoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ContatoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_control.SuspendLayout()
        Me.SuspendLayout()
        '
        'TasksContactsDataSet
        '
        Me.TasksContactsDataSet.DataSetName = "TasksContactsDataSet"
        Me.TasksContactsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TipoContatoBindingSource
        '
        Me.TipoContatoBindingSource.DataMember = "TipoContato"
        Me.TipoContatoBindingSource.DataSource = Me.TasksContactsDataSet
        '
        'TipoContatoTableAdapter
        '
        Me.TipoContatoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ContatoTableAdapter = Nothing
        Me.TableAdapterManager.TarefaTableAdapter = Nothing
        Me.TableAdapterManager.TipoContatoTableAdapter = Me.TipoContatoTableAdapter
        Me.TableAdapterManager.TipoTarefaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Tasks_Contacts.TasksContactsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.UtilizadorTableAdapter = Nothing
        '
        'TipoContatoBindingNavigator
        '
        Me.TipoContatoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TipoContatoBindingNavigator.BindingSource = Me.TipoContatoBindingSource
        Me.TipoContatoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TipoContatoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TipoContatoBindingNavigator.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.TipoContatoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TipoContatoBindingNavigatorSaveItem})
        Me.TipoContatoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TipoContatoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TipoContatoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TipoContatoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TipoContatoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TipoContatoBindingNavigator.Name = "TipoContatoBindingNavigator"
        Me.TipoContatoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TipoContatoBindingNavigator.Size = New System.Drawing.Size(725, 27)
        Me.TipoContatoBindingNavigator.TabIndex = 0
        Me.TipoContatoBindingNavigator.Text = "BindingNavigator1"
        Me.TipoContatoBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorAddNewItem.Text = "Adicionar novo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(48, 24)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de itens"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primeiro"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posição"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 27)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posição actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveNextItem.Text = "Mover seguinte"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(29, 24)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'TipoContatoBindingNavigatorSaveItem
        '
        Me.TipoContatoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TipoContatoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TipoContatoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TipoContatoBindingNavigatorSaveItem.Name = "TipoContatoBindingNavigatorSaveItem"
        Me.TipoContatoBindingNavigatorSaveItem.Size = New System.Drawing.Size(29, 24)
        Me.TipoContatoBindingNavigatorSaveItem.Text = "Salvar Dados"
        '
        'TipoContatoDataGridView
        '
        Me.TipoContatoDataGridView.AutoGenerateColumns = False
        Me.TipoContatoDataGridView.BackgroundColor = System.Drawing.Color.LightCoral
        Me.TipoContatoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TipoContatoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.TipoContatoDataGridView.DataSource = Me.TipoContatoBindingSource
        Me.TipoContatoDataGridView.Location = New System.Drawing.Point(-57, -3)
        Me.TipoContatoDataGridView.Name = "TipoContatoDataGridView"
        Me.TipoContatoDataGridView.RowHeadersWidth = 51
        Me.TipoContatoDataGridView.RowTemplate.Height = 24
        Me.TipoContatoDataGridView.Size = New System.Drawing.Size(425, 375)
        Me.TipoContatoDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "IDTipoCon"
        Me.DataGridViewTextBoxColumn1.HeaderText = "IDTipoCon"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Tipo"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Tipo"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Valor"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Valor"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "IDCon"
        Me.DataGridViewTextBoxColumn4.HeaderText = "IDCon"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'btn_adicionar
        '
        Me.btn_adicionar.BackColor = System.Drawing.Color.Gold
        Me.btn_adicionar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_adicionar.Location = New System.Drawing.Point(406, 11)
        Me.btn_adicionar.Name = "btn_adicionar"
        Me.btn_adicionar.Size = New System.Drawing.Size(147, 32)
        Me.btn_adicionar.TabIndex = 2
        Me.btn_adicionar.Text = "Adicionar"
        Me.btn_adicionar.UseVisualStyleBackColor = False
        '
        'btn_atualizar
        '
        Me.btn_atualizar.BackColor = System.Drawing.Color.DarkOrange
        Me.btn_atualizar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_atualizar.Location = New System.Drawing.Point(559, 11)
        Me.btn_atualizar.Name = "btn_atualizar"
        Me.btn_atualizar.Size = New System.Drawing.Size(147, 32)
        Me.btn_atualizar.TabIndex = 3
        Me.btn_atualizar.Text = "Atualizar"
        Me.btn_atualizar.UseVisualStyleBackColor = False
        '
        'btn_eliminar
        '
        Me.btn_eliminar.BackColor = System.Drawing.Color.Red
        Me.btn_eliminar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_eliminar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_eliminar.Location = New System.Drawing.Point(482, 49)
        Me.btn_eliminar.Name = "btn_eliminar"
        Me.btn_eliminar.Size = New System.Drawing.Size(147, 32)
        Me.btn_eliminar.TabIndex = 4
        Me.btn_eliminar.Text = "Eliminar"
        Me.btn_eliminar.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.SandyBrown
        Me.PictureBox1.Location = New System.Drawing.Point(368, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(16, 371)
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'btn_voltar
        '
        Me.btn_voltar.BackColor = System.Drawing.Color.Gold
        Me.btn_voltar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_voltar.Location = New System.Drawing.Point(603, 319)
        Me.btn_voltar.Name = "btn_voltar"
        Me.btn_voltar.Size = New System.Drawing.Size(110, 35)
        Me.btn_voltar.TabIndex = 6
        Me.btn_voltar.Text = "Voltar"
        Me.btn_voltar.UseVisualStyleBackColor = False
        '
        'txt_Tipo
        '
        Me.txt_Tipo.BackColor = System.Drawing.Color.Gold
        Me.txt_Tipo.Location = New System.Drawing.Point(2, 44)
        Me.txt_Tipo.Name = "txt_Tipo"
        Me.txt_Tipo.Size = New System.Drawing.Size(295, 22)
        Me.txt_Tipo.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.DarkOrange
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label3.Location = New System.Drawing.Point(6, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 26)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Tipo"
        '
        'txt_Valor
        '
        Me.txt_Valor.BackColor = System.Drawing.Color.Gold
        Me.txt_Valor.Location = New System.Drawing.Point(2, 98)
        Me.txt_Valor.Name = "txt_Valor"
        Me.txt_Valor.Size = New System.Drawing.Size(295, 22)
        Me.txt_Valor.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DarkOrange
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label1.Location = New System.Drawing.Point(6, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 26)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Valor"
        '
        'ContatoBindingSource
        '
        Me.ContatoBindingSource.DataMember = "Contato"
        Me.ContatoBindingSource.DataSource = Me.TasksContactsDataSet
        '
        'ContatoTableAdapter
        '
        Me.ContatoTableAdapter.ClearBeforeFill = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkOrange
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!)
        Me.Label2.Location = New System.Drawing.Point(6, 132)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 26)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Contato"
        '
        'cb_Contato
        '
        Me.cb_Contato.BackColor = System.Drawing.Color.Gold
        Me.cb_Contato.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TipoContatoBindingSource, "IDCon", True))
        Me.cb_Contato.DataSource = Me.ContatoBindingSource
        Me.cb_Contato.DisplayMember = "Nome"
        Me.cb_Contato.FormattingEnabled = True
        Me.cb_Contato.Location = New System.Drawing.Point(2, 161)
        Me.cb_Contato.Name = "cb_Contato"
        Me.cb_Contato.Size = New System.Drawing.Size(154, 24)
        Me.cb_Contato.TabIndex = 17
        Me.cb_Contato.ValueMember = "IDCon"
        '
        'btn_guardar
        '
        Me.btn_guardar.BackColor = System.Drawing.Color.Yellow
        Me.btn_guardar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_guardar.Location = New System.Drawing.Point(162, 129)
        Me.btn_guardar.Name = "btn_guardar"
        Me.btn_guardar.Size = New System.Drawing.Size(135, 55)
        Me.btn_guardar.TabIndex = 18
        Me.btn_guardar.Text = "Adicionar"
        Me.btn_guardar.UseVisualStyleBackColor = False
        '
        'gb_control
        '
        Me.gb_control.BackColor = System.Drawing.Color.DarkOrange
        Me.gb_control.Controls.Add(Me.btn_guardar)
        Me.gb_control.Controls.Add(Me.cb_Contato)
        Me.gb_control.Controls.Add(Me.Label2)
        Me.gb_control.Controls.Add(Me.txt_Valor)
        Me.gb_control.Controls.Add(Me.Label1)
        Me.gb_control.Controls.Add(Me.txt_Tipo)
        Me.gb_control.Controls.Add(Me.Label3)
        Me.gb_control.Location = New System.Drawing.Point(399, 101)
        Me.gb_control.Name = "gb_control"
        Me.gb_control.Size = New System.Drawing.Size(307, 202)
        Me.gb_control.TabIndex = 19
        Me.gb_control.TabStop = False
        Me.gb_control.Visible = False
        '
        'TiposContatos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Orange
        Me.ClientSize = New System.Drawing.Size(728, 370)
        Me.Controls.Add(Me.gb_control)
        Me.Controls.Add(Me.btn_voltar)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btn_eliminar)
        Me.Controls.Add(Me.btn_atualizar)
        Me.Controls.Add(Me.btn_adicionar)
        Me.Controls.Add(Me.TipoContatoDataGridView)
        Me.Controls.Add(Me.TipoContatoBindingNavigator)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "TiposContatos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TiposContatos"
        CType(Me.TasksContactsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TipoContatoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TipoContatoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TipoContatoBindingNavigator.ResumeLayout(False)
        Me.TipoContatoBindingNavigator.PerformLayout()
        CType(Me.TipoContatoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ContatoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_control.ResumeLayout(False)
        Me.gb_control.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TasksContactsDataSet As TasksContactsDataSet
    Friend WithEvents TipoContatoBindingSource As BindingSource
    Friend WithEvents TipoContatoTableAdapter As TasksContactsDataSetTableAdapters.TipoContatoTableAdapter
    Friend WithEvents TableAdapterManager As TasksContactsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TipoContatoBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents TipoContatoBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents TipoContatoDataGridView As DataGridView
    Friend WithEvents btn_adicionar As Button
    Friend WithEvents btn_atualizar As Button
    Friend WithEvents btn_eliminar As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btn_voltar As Button
    Friend WithEvents txt_Tipo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_Valor As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents ContatoBindingSource As BindingSource
    Friend WithEvents ContatoTableAdapter As TasksContactsDataSetTableAdapters.ContatoTableAdapter
    Friend WithEvents Label2 As Label
    Friend WithEvents cb_Contato As ComboBox
    Friend WithEvents btn_guardar As Button
    Friend WithEvents gb_control As GroupBox
End Class
