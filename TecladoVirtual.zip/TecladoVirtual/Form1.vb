﻿Imports System.Runtime.Intrinsics.X86

Public Class Form1
    Private shift As Boolean = False
    Private caps As Boolean = False

    Private Sub btn_1_Click(sender As Object, e As EventArgs) Handles btn_P.Click, btn_Ç.Click, btn_L.Click, btn_O.Click, btn_I.Click, btn_K.Click, btn_M.Click, btn_N.Click, btn_J.Click, btn_U.Click, btn_Y.Click, btn_H.Click, btn_B.Click, btn_G.Click, btn_T.Click, btn_R.Click, btn_F.Click, btn_V.Click, btn_C.Click, btn_D.Click, btn_E.Click, btn_W.Click, btn_S.Click, btn_X.Click, btn_Z.Click, btn_A.Click, btn_Q.Click
        Dim btnC As Button = CType(sender, Button)
        Dim texto As String = btnC.Text

        If shift Xor caps Then
            lb_texto.Text = lb_texto.Text & texto.ToUpper
            If shift Then
                shift = False
                Btn_shift.BackColor = Color.Black
                btn_shift2.BackColor = Color.Black
                Btn_shift.ForeColor = Color.White
                btn_shift2.ForeColor = Color.White
                MudarLetra(False)
            End If
        Else
            lb_texto.Text = lb_texto.Text & texto
        End If
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        If lb_texto.Text IsNot "" Then
            lb_texto.Text = lb_texto.Text.Substring(0, lb_texto.Text.Length - 1)
        End If
    End Sub

    Private Sub btn_shift2_Click(sender As Object, e As EventArgs) Handles btn_shift2.Click
        If shift = False Then
            shift = True
            Btn_shift.BackColor = Color.Yellow
            btn_shift2.BackColor = Color.Yellow
            Btn_shift.ForeColor = Color.Black
            btn_shift2.ForeColor = Color.Black
            MudarLetra(True)
            MudarNum()
        Else
            shift = False
            Btn_shift.BackColor = Color.Black
            btn_shift2.BackColor = Color.Black
            Btn_shift.ForeColor = Color.White
            btn_shift2.ForeColor = Color.White
            MudarLetra(False)
            MudarNum()
        End If
    End Sub

    Private Sub Btn_shift_Click(sender As Object, e As EventArgs) Handles Btn_shift.Click
        If shift = False Then
            shift = True
            Btn_shift.BackColor = Color.Yellow
            btn_shift2.BackColor = Color.Yellow
            Btn_shift.ForeColor = Color.Black
            btn_shift2.ForeColor = Color.Black
            MudarLetra(True)
            MudarNum()
        Else
            shift = False
            Btn_shift.BackColor = Color.Black
            btn_shift2.BackColor = Color.Black
            Btn_shift.ForeColor = Color.White
            btn_shift2.ForeColor = Color.White
            MudarLetra(False)
            MudarNum()
        End If
    End Sub

    Private Sub btn_caps_Click(sender As Object, e As EventArgs) Handles btn_caps.Click
        If caps = False Then
            caps = True
            btn_caps.BackColor = Color.Yellow
            btn_caps.ForeColor = Color.Black
            MudarLetra(True)
        Else
            caps = False
            btn_caps.BackColor = Color.Black
            btn_caps.ForeColor = Color.White
            MudarLetra(False)
        End If
    End Sub

    Private Sub btn_space_Click(sender As Object, e As EventArgs) Handles btn_space.Click
        lb_texto.Text = lb_texto.Text & " "

    End Sub

    Private Sub btn_tab_Click(sender As Object, e As EventArgs) Handles btn_tab.Click
        lb_texto.Text = lb_texto.Text & "    "
    End Sub



    Private Function MudarLetra(maior As Boolean)
        If caps And shift Then
            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        cnt.Text = cnt.Text.ToLower
                    End If
                End If
            Next
        Else
            If caps Xor shift Then
                maior = True
            End If

            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        If maior Then
                            cnt.Text = cnt.Text.ToUpper
                        Else
                            cnt.Text = cnt.Text.ToLower
                        End If
                    End If
                End If
            Next
        End If
    End Function

    Private Function MudarNum()
        Dim aux As Char
        aux = btn_0.Text
        btn_0.Text = lb_10.Text
        lb_10.Text = aux

        aux = btn_1.Text
        btn_1.Text = lb_1.Text
        lb_1.Text = aux

        aux = btn_2.Text
        btn_2.Text = lb_2.Text
        lb_2.Text = aux

        aux = btn_3.Text
        btn_3.Text = lb_3.Text
        lb_3.Text = aux

        aux = btn_4.Text
        btn_4.Text = lb_4.Text
        lb_4.Text = aux

        aux = btn_5.Text
        btn_5.Text = lb_5.Text
        lb_5.Text = aux

        aux = btn_6.Text
        btn_6.Text = lb_6.Text
        lb_6.Text = aux

        aux = btn_7.Text
        btn_7.Text = lb_7.Text
        lb_7.Text = aux

        aux = btn_8.Text
        btn_8.Text = lb_8.Text
        lb_8.Text = aux

        aux = btn_9.Text
        btn_9.Text = lb_9.Text
        lb_9.Text = aux

        aux = btn_QueMark.Text
        btn_QueMark.Text = lb_dot.Text
        lb_dot.Text = aux

        aux = btn_arrowT2.Text
        btn_arrowT2.Text = lb_ArrowT2.Text
        lb_ArrowT2.Text = aux

        aux = btn_plus.Text
        btn_plus.Text = lb_hash.Text
        lb_hash.Text = aux

        aux = btn_Asento.Text
        btn_Asento.Text = lb_Asento.Text
        lb_Asento.Text = aux

        aux = btn_º.Text
        btn_º.Text = lb_ª.Text
        lb_ª.Text = aux

        aux = btn_til.Text
        btn_til.Text = lb_hat.Text
        lb_hat.Text = aux

        aux = btn_PonVirg.Text
        btn_PonVirg.Text = lb_PV.Text
        lb_PV.Text = aux

        aux = btn_Ponto.Text
        btn_Ponto.Text = lb_PP.Text
        lb_PP.Text = aux

        aux = btn_Min.Text
        btn_Min.Text = lb_min.Text
        lb_min.Text = aux

        aux = btn_InvBar.Text
        btn_InvBar.Text = lb_InvBar.Text
        lb_InvBar.Text = aux
    End Function

    Private Sub btn_Enter_Click(sender As Object, e As EventArgs) Handles btn_Enter.Click
        lb_texto.Text = lb_texto.Text & Environment.NewLine
    End Sub

    Private Sub btn_1_Click_1(sender As Object, e As EventArgs) Handles btn_1.Click, btn_2.Click, btn_3.Click, btn_4.Click, btn_5.Click, btn_6.Click, btn_7.Click, btn_8.Click, btn_9.Click, btn_0.Click, btn_QueMark.Click, btn_arrowT2.Click, btn_Asento.Click, btn_plus.Click, btn_º.Click, btn_til.Click, btn_Min.Click, btn_Ponto.Click, btn_PonVirg.Click, btn_InvBar.Click
        Dim btnC As Button = CType(sender, Button)
        Dim texto As String = btnC.Text
        If shift Xor caps Then
            lb_texto.Text = lb_texto.Text & texto
            shift = False
            Btn_shift.BackColor = Color.Black
            btn_shift2.BackColor = Color.Black
            Btn_shift.ForeColor = Color.White
            btn_shift2.ForeColor = Color.White
            MudarNum()
        ElseIf shift And caps = False Then
            lb_texto.Text = lb_texto.Text & texto
            MudarNum()
        Else
            lb_texto.Text = lb_texto.Text & texto
        End If
    End Sub
End Class
