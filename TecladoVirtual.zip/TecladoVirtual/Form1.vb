﻿Public Class Form1
    Private shift As Boolean = False
    Private caps As Boolean = False

    Private Sub btn_1_Click(sender As Object, e As EventArgs) Handles btn_P.Click, btn_Ç.Click, btn_L.Click, btn_O.Click, btn_I.Click, btn_K.Click, btn_M.Click, btn_N.Click, btn_J.Click, btn_U.Click, btn_Y.Click, btn_H.Click, btn_B.Click, btn_G.Click, btn_T.Click, btn_R.Click, btn_F.Click, btn_V.Click, btn_C.Click, btn_D.Click, btn_E.Click, btn_W.Click, btn_S.Click, btn_X.Click, btn_Z.Click, btn_A.Click, btn_Q.Click
        Dim btnC As Button = CType(sender, Button)
        Dim texto As String = btnC.Text

        If shift Xor caps Then
            lb_texto.Text = lb_texto.Text & texto.ToUpper
            If shift Then
                shift = False
                Btn_shift.BackColor = Color.Black
                btn_shift2.BackColor = Color.Black
                Btn_shift.ForeColor = Color.White
                btn_shift2.ForeColor = Color.White

            End If

        Else
            lb_texto.Text = lb_texto.Text & texto
        End If
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        If lb_texto.Text IsNot "" Then
            lb_texto.Text = lb_texto.Text.Substring(0, lb_texto.Text.Length - 1)
        End If
    End Sub

    Private Sub btn_shift2_Click(sender As Object, e As EventArgs) Handles btn_shift2.Click
        If shift = False Then
            shift = True
            Btn_shift.BackColor = Color.Yellow
            btn_shift2.BackColor = Color.Yellow
            Btn_shift.ForeColor = Color.Black
            btn_shift2.ForeColor = Color.Black

            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        cnt.Text = cnt.Text.ToUpper
                    End If
                End If
            Next
        Else
            shift = False
            Btn_shift.BackColor = Color.Black
            btn_shift2.BackColor = Color.Black
            Btn_shift.ForeColor = Color.White
            btn_shift2.ForeColor = Color.White

            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        cnt.Text = cnt.Text.ToLower
                    End If
                End If
            Next
        End If
    End Sub

    Private Sub Btn_shift_Click(sender As Object, e As EventArgs) Handles Btn_shift.Click
        If shift = False Then
            shift = True
            Btn_shift.BackColor = Color.Yellow
            btn_shift2.BackColor = Color.Yellow
            Btn_shift.ForeColor = Color.Black
            btn_shift2.ForeColor = Color.Black
            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        cnt.Text = cnt.Text.ToUpper
                    End If
                End If
            Next
        Else
            shift = False
            Btn_shift.BackColor = Color.Black
            btn_shift2.BackColor = Color.Black
            Btn_shift.ForeColor = Color.White
            btn_shift2.ForeColor = Color.White

            For Each cnt As Control In GroupBox1.Controls
                If TypeOf cnt Is Button Then
                    If Char.IsLetter(cnt.Text(0)) And cnt.Text.Length = 1 Then
                        cnt.Text = cnt.Text.ToLower
                    End If
                End If
            Next
        End If
    End Sub

    Private Sub btn_caps_Click(sender As Object, e As EventArgs) Handles btn_caps.Click
        If caps = False Then
            caps = True
            btn_caps.BackColor = Color.Yellow
            btn_caps.ForeColor = Color.Black
        Else
            caps = False
            btn_caps.BackColor = Color.Black
            btn_caps.ForeColor = Color.White
        End If
    End Sub

    Private Sub btn_space_Click(sender As Object, e As EventArgs) Handles btn_space.Click
        lb_texto.Text = lb_texto.Text & " "

    End Sub

    Private Sub btn_tab_Click(sender As Object, e As EventArgs) Handles btn_tab.Click
        lb_texto.Text = lb_texto.Text & "    "
    End Sub

    Private Sub btn_1_Click_1(sender As Object, e As EventArgs) Handles btn_1.Click, btn_2.Click, btn_3.Click, btn_4.Click, btn_5.Click, btn_6.Click, btn_7.Click, btn_8.Click, btn_9.Click, btn_0.Click

    End Sub
End Class
