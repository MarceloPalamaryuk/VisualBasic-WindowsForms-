﻿Public Class Form1
    Public numLetras As Integer = 0
    Private Sub btn_1_Click(sender As Object, e As EventArgs) Handles btn_1.Click, btn_2.Click, btn_3.Click, btn_4.Click, btn_5.Click, btn_6.Click, btn_7.Click, btn_8.Click, btn_9.Click, btn_0.Click, btn_P.Click, btn_Ç.Click, btn_L.Click, btn_O.Click, btn_I.Click, btn_K.Click, btn_M.Click, btn_N.Click, btn_J.Click, btn_U.Click, btn_Y.Click, btn_H.Click, btn_B.Click, btn_G.Click, btn_T.Click, btn_R.Click, btn_F.Click, btn_V.Click, btn_C.Click, btn_D.Click, btn_E.Click, btn_W.Click, btn_S.Click, btn_X.Click, btn_Z.Click, btn_A.Click, btn_Q.Click
        Dim btn_clicado As Button = CType(sender, Button)
        lb_texto.Text = lb_texto.Text & btn_clicado.Text
        numLetras += 1
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Dim numL As Integer = lb_texto.Text.Length


    End Sub
End Class
