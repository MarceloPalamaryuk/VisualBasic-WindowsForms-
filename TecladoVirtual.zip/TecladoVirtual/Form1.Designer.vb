﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btn_space = New Button()
        btn_alt = New Button()
        btn_ctrl = New Button()
        btn_ctrl2 = New Button()
        Btn_shift = New Button()
        btn_arrowT1 = New Button()
        btn_Z = New Button()
        btn_X = New Button()
        btn_C = New Button()
        btn_V = New Button()
        btn_B = New Button()
        btn_N = New Button()
        btn_M = New Button()
        btn_PonVirg = New Button()
        btn_Ponto = New Button()
        btn_Min = New Button()
        lb_PV = New Label()
        lb_PP = New Label()
        lb_min = New Label()
        btn_shift2 = New Button()
        btn_A = New Button()
        btn_S = New Button()
        btn_D = New Button()
        btn_F = New Button()
        btn_G = New Button()
        btn_H = New Button()
        btn_J = New Button()
        btn_K = New Button()
        btn_L = New Button()
        btn_Ç = New Button()
        btn_caps = New Button()
        btn_º = New Button()
        btn_til = New Button()
        lb_ª = New Label()
        lb_hat = New Label()
        btn_Q = New Button()
        btn_W = New Button()
        btn_E = New Button()
        btn_R = New Button()
        btn_T = New Button()
        btn_Y = New Button()
        btn_U = New Button()
        btn_tab = New Button()
        btn_alrGr = New Button()
        btn_plus = New Button()
        btn_Asento = New Button()
        lb_hash = New Label()
        lb_Asento = New Label()
        PictureBox1 = New PictureBox()
        btn_Enter = New Button()
        btn_InvBar = New Button()
        btn_1 = New Button()
        btn_2 = New Button()
        btn_3 = New Button()
        btn_4 = New Button()
        btn_5 = New Button()
        btn_6 = New Button()
        btn_7 = New Button()
        btn_8 = New Button()
        btn_9 = New Button()
        btn_0 = New Button()
        btn_QueMark = New Button()
        btn_arrowT2 = New Button()
        btn_back = New Button()
        lb_1 = New Label()
        lb_2 = New Label()
        lb_InvBar = New Label()
        lb_4 = New Label()
        lb_3 = New Label()
        lb_5 = New Label()
        lb_7 = New Label()
        lb_8 = New Label()
        lb_9 = New Label()
        lb_10 = New Label()
        lb_dot = New Label()
        btn_I = New Button()
        btn_O = New Button()
        btn_P = New Button()
        GroupBox1 = New GroupBox()
        lb_ArrowT2 = New Label()
        lb_6 = New Label()
        lb_texto = New RichTextBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' btn_space
        ' 
        btn_space.BackColor = SystemColors.ActiveCaptionText
        btn_space.ForeColor = SystemColors.Control
        btn_space.Location = New Point(241, 261)
        btn_space.Margin = New Padding(3, 4, 3, 4)
        btn_space.Name = "btn_space"
        btn_space.Size = New Size(310, 49)
        btn_space.TabIndex = 0
        btn_space.Text = "Space"
        btn_space.UseVisualStyleBackColor = False
        ' 
        ' btn_alt
        ' 
        btn_alt.BackColor = SystemColors.ActiveCaptionText
        btn_alt.ForeColor = SystemColors.Control
        btn_alt.Location = New Point(170, 261)
        btn_alt.Margin = New Padding(3, 4, 3, 4)
        btn_alt.Name = "btn_alt"
        btn_alt.Size = New Size(64, 49)
        btn_alt.TabIndex = 2
        btn_alt.Text = "Alt"
        btn_alt.UseVisualStyleBackColor = False
        ' 
        ' btn_ctrl
        ' 
        btn_ctrl.BackColor = SystemColors.ActiveCaptionText
        btn_ctrl.ForeColor = SystemColors.Control
        btn_ctrl.Location = New Point(11, 261)
        btn_ctrl.Margin = New Padding(3, 4, 3, 4)
        btn_ctrl.Name = "btn_ctrl"
        btn_ctrl.Size = New Size(80, 49)
        btn_ctrl.TabIndex = 3
        btn_ctrl.Text = "Ctrl"
        btn_ctrl.UseVisualStyleBackColor = False
        ' 
        ' btn_ctrl2
        ' 
        btn_ctrl2.BackColor = SystemColors.ActiveCaptionText
        btn_ctrl2.ForeColor = SystemColors.Control
        btn_ctrl2.Location = New Point(751, 261)
        btn_ctrl2.Margin = New Padding(3, 4, 3, 4)
        btn_ctrl2.Name = "btn_ctrl2"
        btn_ctrl2.Size = New Size(73, 49)
        btn_ctrl2.TabIndex = 4
        btn_ctrl2.Text = "Ctrl"
        btn_ctrl2.UseVisualStyleBackColor = False
        ' 
        ' Btn_shift
        ' 
        Btn_shift.BackColor = SystemColors.ActiveCaptionText
        Btn_shift.Font = New Font("Segoe UI", 16F)
        Btn_shift.ForeColor = SystemColors.Control
        Btn_shift.Location = New Point(11, 200)
        Btn_shift.Margin = New Padding(3, 4, 3, 4)
        Btn_shift.Name = "Btn_shift"
        Btn_shift.Size = New Size(75, 53)
        Btn_shift.TabIndex = 5
        Btn_shift.Text = "↑"
        Btn_shift.UseVisualStyleBackColor = False
        ' 
        ' btn_arrowT1
        ' 
        btn_arrowT1.BackColor = Color.Black
        btn_arrowT1.Font = New Font("Segoe UI", 16F)
        btn_arrowT1.ForeColor = Color.White
        btn_arrowT1.Location = New Point(94, 200)
        btn_arrowT1.Margin = New Padding(3, 4, 3, 4)
        btn_arrowT1.Name = "btn_arrowT1"
        btn_arrowT1.Size = New Size(48, 53)
        btn_arrowT1.TabIndex = 6
        btn_arrowT1.Text = "<"
        btn_arrowT1.UseVisualStyleBackColor = False
        ' 
        ' btn_Z
        ' 
        btn_Z.BackColor = Color.LightCoral
        btn_Z.Font = New Font("Segoe UI", 16F)
        btn_Z.ForeColor = SystemColors.ButtonHighlight
        btn_Z.Location = New Point(149, 200)
        btn_Z.Margin = New Padding(3, 4, 3, 4)
        btn_Z.Name = "btn_Z"
        btn_Z.Size = New Size(48, 53)
        btn_Z.TabIndex = 7
        btn_Z.Text = "z"
        btn_Z.UseVisualStyleBackColor = False
        ' 
        ' btn_X
        ' 
        btn_X.BackColor = Color.LightCoral
        btn_X.Font = New Font("Segoe UI", 16F)
        btn_X.ForeColor = SystemColors.ButtonHighlight
        btn_X.Location = New Point(203, 200)
        btn_X.Margin = New Padding(3, 4, 3, 4)
        btn_X.Name = "btn_X"
        btn_X.Size = New Size(48, 53)
        btn_X.TabIndex = 8
        btn_X.Text = "x"
        btn_X.UseVisualStyleBackColor = False
        ' 
        ' btn_C
        ' 
        btn_C.BackColor = Color.LightCoral
        btn_C.Font = New Font("Segoe UI", 16F)
        btn_C.ForeColor = SystemColors.ButtonHighlight
        btn_C.Location = New Point(258, 200)
        btn_C.Margin = New Padding(3, 4, 3, 4)
        btn_C.Name = "btn_C"
        btn_C.Size = New Size(48, 53)
        btn_C.TabIndex = 9
        btn_C.Text = "c"
        btn_C.UseVisualStyleBackColor = False
        ' 
        ' btn_V
        ' 
        btn_V.BackColor = Color.LightCoral
        btn_V.Font = New Font("Segoe UI", 16F)
        btn_V.ForeColor = SystemColors.ButtonHighlight
        btn_V.Location = New Point(313, 200)
        btn_V.Margin = New Padding(3, 4, 3, 4)
        btn_V.Name = "btn_V"
        btn_V.Size = New Size(48, 53)
        btn_V.TabIndex = 10
        btn_V.Text = "v"
        btn_V.UseVisualStyleBackColor = False
        ' 
        ' btn_B
        ' 
        btn_B.BackColor = Color.LightCoral
        btn_B.Font = New Font("Segoe UI", 16F)
        btn_B.ForeColor = SystemColors.ButtonHighlight
        btn_B.Location = New Point(368, 200)
        btn_B.Margin = New Padding(3, 4, 3, 4)
        btn_B.Name = "btn_B"
        btn_B.Size = New Size(48, 53)
        btn_B.TabIndex = 11
        btn_B.Text = "b"
        btn_B.UseVisualStyleBackColor = False
        ' 
        ' btn_N
        ' 
        btn_N.BackColor = Color.LightCoral
        btn_N.Font = New Font("Segoe UI", 16F)
        btn_N.ForeColor = SystemColors.ButtonHighlight
        btn_N.Location = New Point(423, 200)
        btn_N.Margin = New Padding(3, 4, 3, 4)
        btn_N.Name = "btn_N"
        btn_N.Size = New Size(48, 53)
        btn_N.TabIndex = 12
        btn_N.Text = "n"
        btn_N.UseVisualStyleBackColor = False
        ' 
        ' btn_M
        ' 
        btn_M.BackColor = Color.LightCoral
        btn_M.Font = New Font("Segoe UI", 16F)
        btn_M.ForeColor = SystemColors.ButtonHighlight
        btn_M.Location = New Point(478, 200)
        btn_M.Margin = New Padding(3, 4, 3, 4)
        btn_M.Name = "btn_M"
        btn_M.Size = New Size(48, 53)
        btn_M.TabIndex = 13
        btn_M.Text = "m"
        btn_M.UseVisualStyleBackColor = False
        ' 
        ' btn_PonVirg
        ' 
        btn_PonVirg.BackColor = SystemColors.ActiveCaptionText
        btn_PonVirg.Font = New Font("Segoe UI", 16F)
        btn_PonVirg.ForeColor = SystemColors.ButtonHighlight
        btn_PonVirg.Location = New Point(533, 200)
        btn_PonVirg.Margin = New Padding(3, 4, 3, 4)
        btn_PonVirg.Name = "btn_PonVirg"
        btn_PonVirg.Size = New Size(48, 53)
        btn_PonVirg.TabIndex = 14
        btn_PonVirg.Text = ","
        btn_PonVirg.UseVisualStyleBackColor = False
        ' 
        ' btn_Ponto
        ' 
        btn_Ponto.BackColor = SystemColors.ActiveCaptionText
        btn_Ponto.Font = New Font("Segoe UI", 16F)
        btn_Ponto.ForeColor = SystemColors.ButtonHighlight
        btn_Ponto.Location = New Point(587, 200)
        btn_Ponto.Margin = New Padding(3, 4, 3, 4)
        btn_Ponto.Name = "btn_Ponto"
        btn_Ponto.Size = New Size(48, 53)
        btn_Ponto.TabIndex = 15
        btn_Ponto.Text = "."
        btn_Ponto.UseVisualStyleBackColor = False
        ' 
        ' btn_Min
        ' 
        btn_Min.BackColor = SystemColors.ActiveCaptionText
        btn_Min.Font = New Font("Segoe UI", 16F)
        btn_Min.ForeColor = SystemColors.ButtonHighlight
        btn_Min.Location = New Point(642, 200)
        btn_Min.Margin = New Padding(3, 4, 3, 4)
        btn_Min.Name = "btn_Min"
        btn_Min.Size = New Size(48, 53)
        btn_Min.TabIndex = 16
        btn_Min.Text = "-"
        btn_Min.UseVisualStyleBackColor = False
        ' 
        ' lb_PV
        ' 
        lb_PV.AutoSize = True
        lb_PV.BackColor = SystemColors.ActiveCaptionText
        lb_PV.Font = New Font("Segoe UI", 12F)
        lb_PV.ForeColor = SystemColors.ButtonHighlight
        lb_PV.Location = New Point(555, 216)
        lb_PV.Name = "lb_PV"
        lb_PV.Size = New Size(16, 28)
        lb_PV.TabIndex = 17
        lb_PV.Text = ";"
        ' 
        ' lb_PP
        ' 
        lb_PP.AutoSize = True
        lb_PP.BackColor = SystemColors.ActiveCaptionText
        lb_PP.Font = New Font("Segoe UI", 12F)
        lb_PP.ForeColor = SystemColors.ButtonHighlight
        lb_PP.Location = New Point(610, 216)
        lb_PP.Name = "lb_PP"
        lb_PP.Size = New Size(16, 28)
        lb_PP.TabIndex = 18
        lb_PP.Text = ":"
        ' 
        ' lb_min
        ' 
        lb_min.AutoSize = True
        lb_min.BackColor = SystemColors.ActiveCaptionText
        lb_min.Font = New Font("Segoe UI", 12F)
        lb_min.ForeColor = SystemColors.ButtonHighlight
        lb_min.Location = New Point(642, 216)
        lb_min.Name = "lb_min"
        lb_min.Size = New Size(20, 28)
        lb_min.TabIndex = 19
        lb_min.Text = "_"
        ' 
        ' btn_shift2
        ' 
        btn_shift2.BackColor = SystemColors.ActiveCaptionText
        btn_shift2.Font = New Font("Segoe UI", 16F)
        btn_shift2.ForeColor = SystemColors.Control
        btn_shift2.Location = New Point(697, 200)
        btn_shift2.Margin = New Padding(3, 4, 3, 4)
        btn_shift2.Name = "btn_shift2"
        btn_shift2.Size = New Size(127, 53)
        btn_shift2.TabIndex = 20
        btn_shift2.Text = "↑"
        btn_shift2.UseVisualStyleBackColor = False
        ' 
        ' btn_A
        ' 
        btn_A.BackColor = Color.LightCoral
        btn_A.Font = New Font("Segoe UI", 16F)
        btn_A.ForeColor = SystemColors.ButtonHighlight
        btn_A.Location = New Point(121, 139)
        btn_A.Margin = New Padding(3, 4, 3, 4)
        btn_A.Name = "btn_A"
        btn_A.Size = New Size(48, 53)
        btn_A.TabIndex = 21
        btn_A.Text = "a"
        btn_A.UseVisualStyleBackColor = False
        ' 
        ' btn_S
        ' 
        btn_S.BackColor = Color.LightCoral
        btn_S.Font = New Font("Segoe UI", 16F)
        btn_S.ForeColor = SystemColors.ButtonHighlight
        btn_S.Location = New Point(176, 139)
        btn_S.Margin = New Padding(3, 4, 3, 4)
        btn_S.Name = "btn_S"
        btn_S.Size = New Size(48, 53)
        btn_S.TabIndex = 22
        btn_S.Text = "s"
        btn_S.UseVisualStyleBackColor = False
        ' 
        ' btn_D
        ' 
        btn_D.BackColor = Color.LightCoral
        btn_D.Font = New Font("Segoe UI", 16F)
        btn_D.ForeColor = SystemColors.ButtonHighlight
        btn_D.Location = New Point(231, 139)
        btn_D.Margin = New Padding(3, 4, 3, 4)
        btn_D.Name = "btn_D"
        btn_D.Size = New Size(48, 53)
        btn_D.TabIndex = 23
        btn_D.Text = "d"
        btn_D.UseVisualStyleBackColor = False
        ' 
        ' btn_F
        ' 
        btn_F.BackColor = Color.LightCoral
        btn_F.Font = New Font("Segoe UI", 16F)
        btn_F.ForeColor = SystemColors.ButtonHighlight
        btn_F.Location = New Point(286, 139)
        btn_F.Margin = New Padding(3, 4, 3, 4)
        btn_F.Name = "btn_F"
        btn_F.Size = New Size(48, 53)
        btn_F.TabIndex = 24
        btn_F.Text = "f"
        btn_F.UseVisualStyleBackColor = False
        ' 
        ' btn_G
        ' 
        btn_G.BackColor = Color.LightCoral
        btn_G.Font = New Font("Segoe UI", 16F)
        btn_G.ForeColor = SystemColors.ButtonHighlight
        btn_G.Location = New Point(341, 139)
        btn_G.Margin = New Padding(3, 4, 3, 4)
        btn_G.Name = "btn_G"
        btn_G.Size = New Size(48, 53)
        btn_G.TabIndex = 25
        btn_G.Text = "g"
        btn_G.UseVisualStyleBackColor = False
        ' 
        ' btn_H
        ' 
        btn_H.BackColor = Color.LightCoral
        btn_H.Font = New Font("Segoe UI", 16F)
        btn_H.ForeColor = SystemColors.ButtonHighlight
        btn_H.Location = New Point(395, 139)
        btn_H.Margin = New Padding(3, 4, 3, 4)
        btn_H.Name = "btn_H"
        btn_H.Size = New Size(48, 53)
        btn_H.TabIndex = 26
        btn_H.Text = "h"
        btn_H.UseVisualStyleBackColor = False
        ' 
        ' btn_J
        ' 
        btn_J.BackColor = Color.LightCoral
        btn_J.Font = New Font("Segoe UI", 16F)
        btn_J.ForeColor = SystemColors.ButtonHighlight
        btn_J.Location = New Point(450, 139)
        btn_J.Margin = New Padding(3, 4, 3, 4)
        btn_J.Name = "btn_J"
        btn_J.Size = New Size(48, 53)
        btn_J.TabIndex = 27
        btn_J.Text = "j"
        btn_J.UseVisualStyleBackColor = False
        ' 
        ' btn_K
        ' 
        btn_K.BackColor = Color.LightCoral
        btn_K.Font = New Font("Segoe UI", 16F)
        btn_K.ForeColor = SystemColors.ButtonHighlight
        btn_K.Location = New Point(501, 139)
        btn_K.Margin = New Padding(3, 4, 3, 4)
        btn_K.Name = "btn_K"
        btn_K.Size = New Size(48, 53)
        btn_K.TabIndex = 28
        btn_K.Text = "k"
        btn_K.UseVisualStyleBackColor = False
        ' 
        ' btn_L
        ' 
        btn_L.BackColor = Color.LightCoral
        btn_L.Font = New Font("Segoe UI", 16F)
        btn_L.ForeColor = SystemColors.ButtonHighlight
        btn_L.Location = New Point(555, 139)
        btn_L.Margin = New Padding(3, 4, 3, 4)
        btn_L.Name = "btn_L"
        btn_L.Size = New Size(48, 53)
        btn_L.TabIndex = 29
        btn_L.Text = "l"
        btn_L.UseVisualStyleBackColor = False
        ' 
        ' btn_Ç
        ' 
        btn_Ç.BackColor = Color.LightCoral
        btn_Ç.Font = New Font("Segoe UI", 16F)
        btn_Ç.ForeColor = SystemColors.ButtonHighlight
        btn_Ç.Location = New Point(610, 139)
        btn_Ç.Margin = New Padding(3, 4, 3, 4)
        btn_Ç.Name = "btn_Ç"
        btn_Ç.Size = New Size(48, 53)
        btn_Ç.TabIndex = 30
        btn_Ç.Text = "ç"
        btn_Ç.UseVisualStyleBackColor = False
        ' 
        ' btn_caps
        ' 
        btn_caps.BackColor = SystemColors.ActiveCaptionText
        btn_caps.Font = New Font("Segoe UI", 9F)
        btn_caps.ForeColor = SystemColors.Control
        btn_caps.Location = New Point(11, 139)
        btn_caps.Margin = New Padding(3, 4, 3, 4)
        btn_caps.Name = "btn_caps"
        btn_caps.Size = New Size(103, 53)
        btn_caps.TabIndex = 31
        btn_caps.Text = "Caps Lock" & vbCrLf & "Ⓐ"
        btn_caps.UseVisualStyleBackColor = False
        ' 
        ' btn_º
        ' 
        btn_º.BackColor = SystemColors.ActiveCaptionText
        btn_º.Font = New Font("Segoe UI", 16F)
        btn_º.ForeColor = SystemColors.ButtonHighlight
        btn_º.Location = New Point(665, 139)
        btn_º.Margin = New Padding(3, 4, 3, 4)
        btn_º.Name = "btn_º"
        btn_º.Size = New Size(48, 53)
        btn_º.TabIndex = 32
        btn_º.Text = "º"
        btn_º.UseVisualStyleBackColor = False
        ' 
        ' btn_til
        ' 
        btn_til.BackColor = SystemColors.ActiveCaptionText
        btn_til.Font = New Font("Segoe UI", 16F)
        btn_til.ForeColor = SystemColors.ButtonHighlight
        btn_til.Location = New Point(720, 139)
        btn_til.Margin = New Padding(3, 4, 3, 4)
        btn_til.Name = "btn_til"
        btn_til.Size = New Size(48, 53)
        btn_til.TabIndex = 33
        btn_til.Text = "~"
        btn_til.UseVisualStyleBackColor = False
        ' 
        ' lb_ª
        ' 
        lb_ª.AutoSize = True
        lb_ª.BackColor = SystemColors.ActiveCaptionText
        lb_ª.Font = New Font("Segoe UI", 12F)
        lb_ª.ForeColor = SystemColors.ButtonHighlight
        lb_ª.Location = New Point(666, 163)
        lb_ª.Name = "lb_ª"
        lb_ª.Size = New Size(20, 28)
        lb_ª.TabIndex = 34
        lb_ª.Text = "ª"
        ' 
        ' lb_hat
        ' 
        lb_hat.AutoSize = True
        lb_hat.BackColor = SystemColors.ActiveCaptionText
        lb_hat.Font = New Font("Segoe UI", 9F)
        lb_hat.ForeColor = SystemColors.ButtonHighlight
        lb_hat.Location = New Point(748, 172)
        lb_hat.Name = "lb_hat"
        lb_hat.Size = New Size(19, 20)
        lb_hat.TabIndex = 35
        lb_hat.Text = "^"
        ' 
        ' btn_Q
        ' 
        btn_Q.BackColor = Color.LightCoral
        btn_Q.Font = New Font("Segoe UI", 16F)
        btn_Q.ForeColor = SystemColors.ButtonHighlight
        btn_Q.Location = New Point(94, 77)
        btn_Q.Margin = New Padding(3, 4, 3, 4)
        btn_Q.Name = "btn_Q"
        btn_Q.Size = New Size(48, 53)
        btn_Q.TabIndex = 36
        btn_Q.Text = "q"
        btn_Q.UseVisualStyleBackColor = False
        ' 
        ' btn_W
        ' 
        btn_W.BackColor = Color.LightCoral
        btn_W.Font = New Font("Segoe UI", 16F)
        btn_W.ForeColor = SystemColors.ButtonHighlight
        btn_W.Location = New Point(149, 77)
        btn_W.Margin = New Padding(3, 4, 3, 4)
        btn_W.Name = "btn_W"
        btn_W.Size = New Size(48, 53)
        btn_W.TabIndex = 37
        btn_W.Text = "w"
        btn_W.UseVisualStyleBackColor = False
        ' 
        ' btn_E
        ' 
        btn_E.BackColor = Color.LightCoral
        btn_E.Font = New Font("Segoe UI", 16F)
        btn_E.ForeColor = SystemColors.ButtonHighlight
        btn_E.Location = New Point(203, 77)
        btn_E.Margin = New Padding(3, 4, 3, 4)
        btn_E.Name = "btn_E"
        btn_E.Size = New Size(48, 53)
        btn_E.TabIndex = 38
        btn_E.Text = "e"
        btn_E.UseVisualStyleBackColor = False
        ' 
        ' btn_R
        ' 
        btn_R.BackColor = Color.LightCoral
        btn_R.Font = New Font("Segoe UI", 16F)
        btn_R.ForeColor = SystemColors.ButtonHighlight
        btn_R.Location = New Point(258, 77)
        btn_R.Margin = New Padding(3, 4, 3, 4)
        btn_R.Name = "btn_R"
        btn_R.Size = New Size(48, 53)
        btn_R.TabIndex = 39
        btn_R.Text = "r"
        btn_R.UseVisualStyleBackColor = False
        ' 
        ' btn_T
        ' 
        btn_T.BackColor = Color.LightCoral
        btn_T.Font = New Font("Segoe UI", 16F)
        btn_T.ForeColor = SystemColors.ButtonHighlight
        btn_T.Location = New Point(313, 77)
        btn_T.Margin = New Padding(3, 4, 3, 4)
        btn_T.Name = "btn_T"
        btn_T.Size = New Size(48, 53)
        btn_T.TabIndex = 40
        btn_T.Text = "t"
        btn_T.UseVisualStyleBackColor = False
        ' 
        ' btn_Y
        ' 
        btn_Y.BackColor = Color.LightCoral
        btn_Y.Font = New Font("Segoe UI", 16F)
        btn_Y.ForeColor = SystemColors.ButtonHighlight
        btn_Y.Location = New Point(368, 77)
        btn_Y.Margin = New Padding(3, 4, 3, 4)
        btn_Y.Name = "btn_Y"
        btn_Y.Size = New Size(48, 53)
        btn_Y.TabIndex = 41
        btn_Y.Text = "y"
        btn_Y.UseVisualStyleBackColor = False
        ' 
        ' btn_U
        ' 
        btn_U.BackColor = Color.LightCoral
        btn_U.Font = New Font("Segoe UI", 16F)
        btn_U.ForeColor = SystemColors.ButtonHighlight
        btn_U.Location = New Point(423, 77)
        btn_U.Margin = New Padding(3, 4, 3, 4)
        btn_U.Name = "btn_U"
        btn_U.Size = New Size(48, 53)
        btn_U.TabIndex = 42
        btn_U.Text = "u"
        btn_U.UseVisualStyleBackColor = False
        ' 
        ' btn_tab
        ' 
        btn_tab.BackColor = SystemColors.ActiveCaptionText
        btn_tab.Font = New Font("Segoe UI", 18F)
        btn_tab.ForeColor = SystemColors.Control
        btn_tab.Location = New Point(11, 77)
        btn_tab.Margin = New Padding(3, 4, 3, 4)
        btn_tab.Name = "btn_tab"
        btn_tab.Size = New Size(75, 53)
        btn_tab.TabIndex = 46
        btn_tab.Text = "↹"
        btn_tab.UseVisualStyleBackColor = False
        ' 
        ' btn_alrGr
        ' 
        btn_alrGr.BackColor = SystemColors.ActiveCaptionText
        btn_alrGr.ForeColor = SystemColors.Control
        btn_alrGr.Location = New Point(555, 261)
        btn_alrGr.Margin = New Padding(3, 4, 3, 4)
        btn_alrGr.Name = "btn_alrGr"
        btn_alrGr.Size = New Size(64, 49)
        btn_alrGr.TabIndex = 48
        btn_alrGr.Text = "AltGr"
        btn_alrGr.UseVisualStyleBackColor = False
        ' 
        ' btn_plus
        ' 
        btn_plus.BackColor = SystemColors.ActiveCaptionText
        btn_plus.Font = New Font("Segoe UI", 16F)
        btn_plus.ForeColor = SystemColors.ButtonHighlight
        btn_plus.Location = New Point(638, 77)
        btn_plus.Margin = New Padding(3, 4, 3, 4)
        btn_plus.Name = "btn_plus"
        btn_plus.Size = New Size(48, 53)
        btn_plus.TabIndex = 49
        btn_plus.Text = "+"
        btn_plus.UseVisualStyleBackColor = False
        ' 
        ' btn_Asento
        ' 
        btn_Asento.BackColor = SystemColors.ActiveCaptionText
        btn_Asento.Font = New Font("Segoe UI", 16F)
        btn_Asento.ForeColor = SystemColors.ButtonHighlight
        btn_Asento.Location = New Point(693, 77)
        btn_Asento.Margin = New Padding(3, 4, 3, 4)
        btn_Asento.Name = "btn_Asento"
        btn_Asento.Size = New Size(48, 53)
        btn_Asento.TabIndex = 50
        btn_Asento.Text = "´"
        btn_Asento.UseVisualStyleBackColor = False
        ' 
        ' lb_hash
        ' 
        lb_hash.AutoSize = True
        lb_hash.BackColor = SystemColors.ActiveCaptionText
        lb_hash.Font = New Font("Segoe UI", 9F)
        lb_hash.ForeColor = SystemColors.ButtonHighlight
        lb_hash.Location = New Point(642, 80)
        lb_hash.Name = "lb_hash"
        lb_hash.Size = New Size(15, 20)
        lb_hash.TabIndex = 51
        lb_hash.Text = "*"
        ' 
        ' lb_Asento
        ' 
        lb_Asento.AutoSize = True
        lb_Asento.BackColor = SystemColors.ActiveCaptionText
        lb_Asento.Font = New Font("Segoe UI", 9F)
        lb_Asento.ForeColor = SystemColors.ButtonHighlight
        lb_Asento.Location = New Point(702, 100)
        lb_Asento.Name = "lb_Asento"
        lb_Asento.Size = New Size(13, 20)
        lb_Asento.TabIndex = 53
        lb_Asento.Text = "`"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ActiveCaptionText
        PictureBox1.Location = New Point(751, 80)
        PictureBox1.Margin = New Padding(3, 4, 3, 4)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(72, 47)
        PictureBox1.TabIndex = 54
        PictureBox1.TabStop = False
        ' 
        ' btn_Enter
        ' 
        btn_Enter.BackColor = SystemColors.ActiveCaptionText
        btn_Enter.Font = New Font("Segoe UI", 20F)
        btn_Enter.ForeColor = SystemColors.Control
        btn_Enter.Location = New Point(773, 77)
        btn_Enter.Margin = New Padding(3, 4, 3, 4)
        btn_Enter.Name = "btn_Enter"
        btn_Enter.Size = New Size(56, 115)
        btn_Enter.TabIndex = 55
        btn_Enter.Text = "↵"
        btn_Enter.UseVisualStyleBackColor = False
        ' 
        ' btn_InvBar
        ' 
        btn_InvBar.BackColor = SystemColors.ActiveCaptionText
        btn_InvBar.Font = New Font("Segoe UI", 16F)
        btn_InvBar.ForeColor = SystemColors.ButtonHighlight
        btn_InvBar.Location = New Point(16, 16)
        btn_InvBar.Margin = New Padding(3, 4, 3, 4)
        btn_InvBar.Name = "btn_InvBar"
        btn_InvBar.Size = New Size(48, 53)
        btn_InvBar.TabIndex = 56
        btn_InvBar.Text = "\"
        btn_InvBar.UseVisualStyleBackColor = False
        ' 
        ' btn_1
        ' 
        btn_1.BackColor = Color.MediumAquamarine
        btn_1.Font = New Font("Segoe UI", 13F)
        btn_1.ForeColor = SystemColors.ActiveCaptionText
        btn_1.Location = New Point(71, 16)
        btn_1.Margin = New Padding(3, 4, 3, 4)
        btn_1.Name = "btn_1"
        btn_1.Size = New Size(48, 53)
        btn_1.TabIndex = 57
        btn_1.Text = "1"
        btn_1.UseVisualStyleBackColor = False
        ' 
        ' btn_2
        ' 
        btn_2.BackColor = Color.MediumAquamarine
        btn_2.Font = New Font("Segoe UI", 13F)
        btn_2.ForeColor = SystemColors.ActiveCaptionText
        btn_2.Location = New Point(126, 16)
        btn_2.Margin = New Padding(3, 4, 3, 4)
        btn_2.Name = "btn_2"
        btn_2.Size = New Size(48, 53)
        btn_2.TabIndex = 58
        btn_2.Text = "2"
        btn_2.UseVisualStyleBackColor = False
        ' 
        ' btn_3
        ' 
        btn_3.BackColor = Color.MediumAquamarine
        btn_3.Font = New Font("Segoe UI", 13F)
        btn_3.ForeColor = SystemColors.ActiveCaptionText
        btn_3.Location = New Point(181, 16)
        btn_3.Margin = New Padding(3, 4, 3, 4)
        btn_3.Name = "btn_3"
        btn_3.Size = New Size(48, 53)
        btn_3.TabIndex = 59
        btn_3.Text = "3"
        btn_3.UseVisualStyleBackColor = False
        ' 
        ' btn_4
        ' 
        btn_4.BackColor = Color.MediumAquamarine
        btn_4.Font = New Font("Segoe UI", 13F)
        btn_4.ForeColor = SystemColors.ActiveCaptionText
        btn_4.Location = New Point(235, 16)
        btn_4.Margin = New Padding(3, 4, 3, 4)
        btn_4.Name = "btn_4"
        btn_4.Size = New Size(48, 53)
        btn_4.TabIndex = 60
        btn_4.Text = "4"
        btn_4.UseVisualStyleBackColor = False
        ' 
        ' btn_5
        ' 
        btn_5.BackColor = Color.MediumAquamarine
        btn_5.Font = New Font("Segoe UI", 13F)
        btn_5.ForeColor = SystemColors.ActiveCaptionText
        btn_5.Location = New Point(290, 16)
        btn_5.Margin = New Padding(3, 4, 3, 4)
        btn_5.Name = "btn_5"
        btn_5.Size = New Size(48, 53)
        btn_5.TabIndex = 61
        btn_5.Text = "5"
        btn_5.UseVisualStyleBackColor = False
        ' 
        ' btn_6
        ' 
        btn_6.BackColor = Color.MediumAquamarine
        btn_6.Font = New Font("Segoe UI", 13F)
        btn_6.ForeColor = SystemColors.ActiveCaptionText
        btn_6.Location = New Point(345, 16)
        btn_6.Margin = New Padding(3, 4, 3, 4)
        btn_6.Name = "btn_6"
        btn_6.Size = New Size(48, 53)
        btn_6.TabIndex = 62
        btn_6.Text = "6"
        btn_6.UseVisualStyleBackColor = False
        ' 
        ' btn_7
        ' 
        btn_7.BackColor = Color.MediumAquamarine
        btn_7.Font = New Font("Segoe UI", 13F)
        btn_7.ForeColor = SystemColors.ActiveCaptionText
        btn_7.Location = New Point(395, 16)
        btn_7.Margin = New Padding(3, 4, 3, 4)
        btn_7.Name = "btn_7"
        btn_7.Size = New Size(48, 53)
        btn_7.TabIndex = 63
        btn_7.Text = "7"
        btn_7.UseVisualStyleBackColor = False
        ' 
        ' btn_8
        ' 
        btn_8.BackColor = Color.MediumAquamarine
        btn_8.Font = New Font("Segoe UI", 13F)
        btn_8.ForeColor = SystemColors.ActiveCaptionText
        btn_8.Location = New Point(450, 16)
        btn_8.Margin = New Padding(3, 4, 3, 4)
        btn_8.Name = "btn_8"
        btn_8.Size = New Size(48, 53)
        btn_8.TabIndex = 64
        btn_8.Text = "8"
        btn_8.UseVisualStyleBackColor = False
        ' 
        ' btn_9
        ' 
        btn_9.BackColor = Color.MediumAquamarine
        btn_9.Font = New Font("Segoe UI", 13F)
        btn_9.ForeColor = SystemColors.ActiveCaptionText
        btn_9.Location = New Point(505, 16)
        btn_9.Margin = New Padding(3, 4, 3, 4)
        btn_9.Name = "btn_9"
        btn_9.Size = New Size(48, 53)
        btn_9.TabIndex = 65
        btn_9.Text = "9"
        btn_9.UseVisualStyleBackColor = False
        ' 
        ' btn_0
        ' 
        btn_0.BackColor = Color.MediumAquamarine
        btn_0.Font = New Font("Segoe UI", 13F)
        btn_0.ForeColor = SystemColors.ActiveCaptionText
        btn_0.Location = New Point(560, 16)
        btn_0.Margin = New Padding(3, 4, 3, 4)
        btn_0.Name = "btn_0"
        btn_0.Size = New Size(48, 53)
        btn_0.TabIndex = 66
        btn_0.Text = "0"
        btn_0.UseVisualStyleBackColor = False
        ' 
        ' btn_QueMark
        ' 
        btn_QueMark.BackColor = SystemColors.ActiveCaptionText
        btn_QueMark.Font = New Font("Segoe UI", 16F)
        btn_QueMark.ForeColor = SystemColors.ButtonHighlight
        btn_QueMark.Location = New Point(611, 16)
        btn_QueMark.Margin = New Padding(3, 4, 3, 4)
        btn_QueMark.Name = "btn_QueMark"
        btn_QueMark.Size = New Size(48, 53)
        btn_QueMark.TabIndex = 67
        btn_QueMark.Text = "?"
        btn_QueMark.UseVisualStyleBackColor = False
        ' 
        ' btn_arrowT2
        ' 
        btn_arrowT2.BackColor = SystemColors.ActiveCaptionText
        btn_arrowT2.Font = New Font("Segoe UI", 9F)
        btn_arrowT2.ForeColor = SystemColors.ButtonHighlight
        btn_arrowT2.Location = New Point(664, 16)
        btn_arrowT2.Margin = New Padding(3, 4, 3, 4)
        btn_arrowT2.Name = "btn_arrowT2"
        btn_arrowT2.Size = New Size(48, 53)
        btn_arrowT2.TabIndex = 68
        btn_arrowT2.Text = "«"
        btn_arrowT2.UseVisualStyleBackColor = False
        ' 
        ' btn_back
        ' 
        btn_back.BackColor = SystemColors.ActiveCaptionText
        btn_back.Font = New Font("Segoe UI", 16F)
        btn_back.ForeColor = SystemColors.Control
        btn_back.Location = New Point(720, 16)
        btn_back.Margin = New Padding(3, 4, 3, 4)
        btn_back.Name = "btn_back"
        btn_back.Size = New Size(109, 53)
        btn_back.TabIndex = 69
        btn_back.Text = "⌫"
        btn_back.UseVisualStyleBackColor = False
        ' 
        ' lb_1
        ' 
        lb_1.AutoSize = True
        lb_1.BackColor = Color.MediumAquamarine
        lb_1.Enabled = False
        lb_1.Font = New Font("Segoe UI", 9F)
        lb_1.ForeColor = SystemColors.ActiveCaptionText
        lb_1.Location = New Point(103, 33)
        lb_1.Name = "lb_1"
        lb_1.Size = New Size(13, 20)
        lb_1.TabIndex = 70
        lb_1.Text = "!"
        ' 
        ' lb_2
        ' 
        lb_2.AutoSize = True
        lb_2.BackColor = Color.MediumAquamarine
        lb_2.Enabled = False
        lb_2.Font = New Font("Segoe UI", 10F)
        lb_2.ForeColor = SystemColors.ActiveCaptionText
        lb_2.Location = New Point(153, 24)
        lb_2.Name = "lb_2"
        lb_2.Size = New Size(17, 23)
        lb_2.TabIndex = 72
        lb_2.Text = """"
        ' 
        ' lb_InvBar
        ' 
        lb_InvBar.AutoSize = True
        lb_InvBar.BackColor = SystemColors.ActiveCaptionText
        lb_InvBar.Font = New Font("Segoe UI", 9F)
        lb_InvBar.ForeColor = SystemColors.ButtonHighlight
        lb_InvBar.Location = New Point(40, 27)
        lb_InvBar.Name = "lb_InvBar"
        lb_InvBar.Size = New Size(13, 20)
        lb_InvBar.TabIndex = 73
        lb_InvBar.Text = "|"
        ' 
        ' lb_4
        ' 
        lb_4.AutoSize = True
        lb_4.BackColor = Color.MediumAquamarine
        lb_4.Enabled = False
        lb_4.Font = New Font("Segoe UI", 9F)
        lb_4.ForeColor = SystemColors.ActiveCaptionText
        lb_4.Location = New Point(264, 24)
        lb_4.Name = "lb_4"
        lb_4.Size = New Size(17, 20)
        lb_4.TabIndex = 75
        lb_4.Text = "$"
        ' 
        ' lb_3
        ' 
        lb_3.AutoSize = True
        lb_3.BackColor = Color.MediumAquamarine
        lb_3.Enabled = False
        lb_3.Font = New Font("Segoe UI", 9F)
        lb_3.ForeColor = SystemColors.ActiveCaptionText
        lb_3.Location = New Point(208, 24)
        lb_3.Name = "lb_3"
        lb_3.Size = New Size(18, 20)
        lb_3.TabIndex = 77
        lb_3.Text = "#"
        ' 
        ' lb_5
        ' 
        lb_5.AutoSize = True
        lb_5.BackColor = Color.MediumAquamarine
        lb_5.Enabled = False
        lb_5.Font = New Font("Segoe UI", 7F)
        lb_5.ForeColor = SystemColors.ActiveCaptionText
        lb_5.Location = New Point(318, 24)
        lb_5.Name = "lb_5"
        lb_5.Size = New Size(17, 15)
        lb_5.TabIndex = 79
        lb_5.Text = "%"
        ' 
        ' lb_7
        ' 
        lb_7.AutoSize = True
        lb_7.BackColor = Color.MediumAquamarine
        lb_7.Enabled = False
        lb_7.Font = New Font("Segoe UI", 7F)
        lb_7.ForeColor = SystemColors.ActiveCaptionText
        lb_7.Location = New Point(423, 24)
        lb_7.Name = "lb_7"
        lb_7.Size = New Size(12, 15)
        lb_7.TabIndex = 80
        lb_7.Text = "/"
        ' 
        ' lb_8
        ' 
        lb_8.AutoSize = True
        lb_8.BackColor = Color.MediumAquamarine
        lb_8.Enabled = False
        lb_8.Font = New Font("Segoe UI", 7F)
        lb_8.ForeColor = SystemColors.ActiveCaptionText
        lb_8.Location = New Point(478, 24)
        lb_8.Name = "lb_8"
        lb_8.Size = New Size(11, 15)
        lb_8.TabIndex = 82
        lb_8.Text = "("
        ' 
        ' lb_9
        ' 
        lb_9.AutoSize = True
        lb_9.BackColor = Color.MediumAquamarine
        lb_9.Enabled = False
        lb_9.Font = New Font("Segoe UI", 7F)
        lb_9.ForeColor = SystemColors.ActiveCaptionText
        lb_9.Location = New Point(533, 24)
        lb_9.Name = "lb_9"
        lb_9.Size = New Size(11, 15)
        lb_9.TabIndex = 84
        lb_9.Text = ")"
        ' 
        ' lb_10
        ' 
        lb_10.AutoSize = True
        lb_10.BackColor = Color.MediumAquamarine
        lb_10.Enabled = False
        lb_10.Font = New Font("Segoe UI", 7F)
        lb_10.ForeColor = SystemColors.ActiveCaptionText
        lb_10.Location = New Point(587, 24)
        lb_10.Name = "lb_10"
        lb_10.Size = New Size(15, 15)
        lb_10.TabIndex = 86
        lb_10.Text = "="
        ' 
        ' lb_dot
        ' 
        lb_dot.AutoSize = True
        lb_dot.BackColor = SystemColors.ActiveCaptionText
        lb_dot.Font = New Font("Segoe UI", 7F)
        lb_dot.ForeColor = SystemColors.ButtonHighlight
        lb_dot.Location = New Point(638, 41)
        lb_dot.Name = "lb_dot"
        lb_dot.Size = New Size(10, 15)
        lb_dot.TabIndex = 88
        lb_dot.Text = "'"
        ' 
        ' btn_I
        ' 
        btn_I.BackColor = Color.LightCoral
        btn_I.Font = New Font("Segoe UI", 16F)
        btn_I.ForeColor = SystemColors.ButtonHighlight
        btn_I.Location = New Point(478, 77)
        btn_I.Margin = New Padding(3, 4, 3, 4)
        btn_I.Name = "btn_I"
        btn_I.Size = New Size(48, 53)
        btn_I.TabIndex = 89
        btn_I.Text = "i"
        btn_I.UseVisualStyleBackColor = False
        ' 
        ' btn_O
        ' 
        btn_O.BackColor = Color.LightCoral
        btn_O.Font = New Font("Segoe UI", 16F)
        btn_O.ForeColor = SystemColors.ButtonHighlight
        btn_O.Location = New Point(533, 77)
        btn_O.Margin = New Padding(3, 4, 3, 4)
        btn_O.Name = "btn_O"
        btn_O.Size = New Size(48, 53)
        btn_O.TabIndex = 90
        btn_O.Text = "o"
        btn_O.UseVisualStyleBackColor = False
        ' 
        ' btn_P
        ' 
        btn_P.BackColor = Color.LightCoral
        btn_P.Font = New Font("Segoe UI", 16F)
        btn_P.ForeColor = SystemColors.ButtonHighlight
        btn_P.Location = New Point(587, 77)
        btn_P.Margin = New Padding(3, 4, 3, 4)
        btn_P.Name = "btn_P"
        btn_P.Size = New Size(48, 53)
        btn_P.TabIndex = 91
        btn_P.Text = "p"
        btn_P.UseVisualStyleBackColor = False
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackColor = Color.DarkGray
        GroupBox1.Controls.Add(lb_ArrowT2)
        GroupBox1.Controls.Add(lb_6)
        GroupBox1.Controls.Add(btn_P)
        GroupBox1.Controls.Add(btn_O)
        GroupBox1.Controls.Add(btn_I)
        GroupBox1.Controls.Add(lb_dot)
        GroupBox1.Controls.Add(lb_10)
        GroupBox1.Controls.Add(lb_9)
        GroupBox1.Controls.Add(lb_8)
        GroupBox1.Controls.Add(lb_7)
        GroupBox1.Controls.Add(lb_5)
        GroupBox1.Controls.Add(lb_3)
        GroupBox1.Controls.Add(lb_4)
        GroupBox1.Controls.Add(lb_InvBar)
        GroupBox1.Controls.Add(lb_2)
        GroupBox1.Controls.Add(lb_1)
        GroupBox1.Controls.Add(btn_back)
        GroupBox1.Controls.Add(btn_arrowT2)
        GroupBox1.Controls.Add(btn_QueMark)
        GroupBox1.Controls.Add(btn_0)
        GroupBox1.Controls.Add(btn_9)
        GroupBox1.Controls.Add(btn_8)
        GroupBox1.Controls.Add(btn_7)
        GroupBox1.Controls.Add(btn_6)
        GroupBox1.Controls.Add(btn_5)
        GroupBox1.Controls.Add(btn_4)
        GroupBox1.Controls.Add(btn_3)
        GroupBox1.Controls.Add(btn_2)
        GroupBox1.Controls.Add(btn_1)
        GroupBox1.Controls.Add(btn_InvBar)
        GroupBox1.Controls.Add(btn_Enter)
        GroupBox1.Controls.Add(PictureBox1)
        GroupBox1.Controls.Add(lb_Asento)
        GroupBox1.Controls.Add(lb_hash)
        GroupBox1.Controls.Add(btn_Asento)
        GroupBox1.Controls.Add(btn_plus)
        GroupBox1.Controls.Add(btn_alrGr)
        GroupBox1.Controls.Add(btn_tab)
        GroupBox1.Controls.Add(btn_U)
        GroupBox1.Controls.Add(btn_Y)
        GroupBox1.Controls.Add(btn_T)
        GroupBox1.Controls.Add(btn_R)
        GroupBox1.Controls.Add(btn_E)
        GroupBox1.Controls.Add(btn_W)
        GroupBox1.Controls.Add(btn_Q)
        GroupBox1.Controls.Add(lb_hat)
        GroupBox1.Controls.Add(lb_ª)
        GroupBox1.Controls.Add(btn_til)
        GroupBox1.Controls.Add(btn_º)
        GroupBox1.Controls.Add(btn_caps)
        GroupBox1.Controls.Add(btn_Ç)
        GroupBox1.Controls.Add(btn_L)
        GroupBox1.Controls.Add(btn_K)
        GroupBox1.Controls.Add(btn_J)
        GroupBox1.Controls.Add(btn_H)
        GroupBox1.Controls.Add(btn_G)
        GroupBox1.Controls.Add(btn_F)
        GroupBox1.Controls.Add(btn_D)
        GroupBox1.Controls.Add(btn_S)
        GroupBox1.Controls.Add(btn_A)
        GroupBox1.Controls.Add(btn_shift2)
        GroupBox1.Controls.Add(lb_min)
        GroupBox1.Controls.Add(lb_PP)
        GroupBox1.Controls.Add(lb_PV)
        GroupBox1.Controls.Add(btn_Min)
        GroupBox1.Controls.Add(btn_Ponto)
        GroupBox1.Controls.Add(btn_PonVirg)
        GroupBox1.Controls.Add(btn_M)
        GroupBox1.Controls.Add(btn_N)
        GroupBox1.Controls.Add(btn_B)
        GroupBox1.Controls.Add(btn_V)
        GroupBox1.Controls.Add(btn_C)
        GroupBox1.Controls.Add(btn_X)
        GroupBox1.Controls.Add(btn_Z)
        GroupBox1.Controls.Add(btn_arrowT1)
        GroupBox1.Controls.Add(Btn_shift)
        GroupBox1.Controls.Add(btn_ctrl2)
        GroupBox1.Controls.Add(btn_ctrl)
        GroupBox1.Controls.Add(btn_alt)
        GroupBox1.Controls.Add(btn_space)
        GroupBox1.Location = New Point(37, 457)
        GroupBox1.Margin = New Padding(3, 4, 3, 4)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Padding = New Padding(3, 4, 3, 4)
        GroupBox1.Size = New Size(842, 320)
        GroupBox1.TabIndex = 92
        GroupBox1.TabStop = False
        ' 
        ' lb_ArrowT2
        ' 
        lb_ArrowT2.AutoSize = True
        lb_ArrowT2.BackColor = SystemColors.ActiveCaptionText
        lb_ArrowT2.Font = New Font("Segoe UI", 7F)
        lb_ArrowT2.ForeColor = SystemColors.ButtonHighlight
        lb_ArrowT2.Location = New Point(693, 46)
        lb_ArrowT2.Name = "lb_ArrowT2"
        lb_ArrowT2.Size = New Size(13, 15)
        lb_ArrowT2.TabIndex = 93
        lb_ArrowT2.Text = "»"
        ' 
        ' lb_6
        ' 
        lb_6.AutoSize = True
        lb_6.BackColor = Color.MediumAquamarine
        lb_6.Enabled = False
        lb_6.Font = New Font("Segoe UI", 7F)
        lb_6.ForeColor = SystemColors.ActiveCaptionText
        lb_6.Location = New Point(374, 24)
        lb_6.Name = "lb_6"
        lb_6.Size = New Size(7, 15)
        lb_6.TabIndex = 92
        lb_6.Text = "&"
        ' 
        ' lb_texto
        ' 
        lb_texto.BackColor = SystemColors.ActiveCaptionText
        lb_texto.Cursor = Cursors.IBeam
        lb_texto.ForeColor = SystemColors.MenuBar
        lb_texto.Location = New Point(53, 33)
        lb_texto.Name = "lb_texto"
        lb_texto.ReadOnly = True
        lb_texto.Size = New Size(807, 397)
        lb_texto.TabIndex = 93
        lb_texto.Text = ""
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(905, 793)
        Controls.Add(lb_texto)
        Controls.Add(GroupBox1)
        Margin = New Padding(3, 4, 3, 4)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
    End Sub
    Friend WithEvents btn_space As Button
    Friend WithEvents btn_alt As Button
    Friend WithEvents btn_ctrl As Button
    Friend WithEvents btn_ctrl2 As Button
    Friend WithEvents Btn_shift As Button
    Friend WithEvents btn_arrowT1 As Button
    Friend WithEvents btn_Z As Button
    Friend WithEvents btn_X As Button
    Friend WithEvents btn_C As Button
    Friend WithEvents btn_V As Button
    Friend WithEvents btn_B As Button
    Friend WithEvents btn_N As Button
    Friend WithEvents btn_M As Button
    Friend WithEvents btn_PonVirg As Button
    Friend WithEvents btn_Ponto As Button
    Friend WithEvents btn_Min As Button
    Friend WithEvents lb_PV As Label
    Friend WithEvents lb_PP As Label
    Friend WithEvents lb_min As Label
    Friend WithEvents btn_shift2 As Button
    Friend WithEvents btn_A As Button
    Friend WithEvents btn_S As Button
    Friend WithEvents btn_D As Button
    Friend WithEvents btn_F As Button
    Friend WithEvents btn_G As Button
    Friend WithEvents btn_H As Button
    Friend WithEvents btn_J As Button
    Friend WithEvents btn_K As Button
    Friend WithEvents btn_L As Button
    Friend WithEvents btn_Ç As Button
    Friend WithEvents btn_caps As Button
    Friend WithEvents btn_º As Button
    Friend WithEvents btn_til As Button
    Friend WithEvents lb_ª As Label
    Friend WithEvents lb_hat As Label
    Friend WithEvents btn_Q As Button
    Friend WithEvents btn_W As Button
    Friend WithEvents btn_E As Button
    Friend WithEvents btn_R As Button
    Friend WithEvents btn_T As Button
    Friend WithEvents btn_Y As Button
    Friend WithEvents btn_U As Button
    Friend WithEvents btn_tab As Button
    Friend WithEvents btn_alrGr As Button
    Friend WithEvents btn_plus As Button
    Friend WithEvents btn_Asento As Button
    Friend WithEvents lb_hash As Label
    Friend WithEvents lb_Asento As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btn_Enter As Button
    Friend WithEvents btn_InvBar As Button
    Friend WithEvents btn_1 As Button
    Friend WithEvents btn_2 As Button
    Friend WithEvents btn_3 As Button
    Friend WithEvents btn_4 As Button
    Friend WithEvents btn_5 As Button
    Friend WithEvents btn_6 As Button
    Friend WithEvents btn_7 As Button
    Friend WithEvents btn_8 As Button
    Friend WithEvents btn_9 As Button
    Friend WithEvents btn_0 As Button
    Friend WithEvents btn_QueMark As Button
    Friend WithEvents btn_arrowT2 As Button
    Friend WithEvents btn_back As Button
    Friend WithEvents lb_1 As Label
    Friend WithEvents lb_2 As Label
    Friend WithEvents lb_InvBar As Label
    Friend WithEvents lb_4 As Label
    Friend WithEvents lb_3 As Label
    Friend WithEvents lb_5 As Label
    Friend WithEvents lb_7 As Label
    Friend WithEvents lb_8 As Label
    Friend WithEvents lb_9 As Label
    Friend WithEvents lb_10 As Label
    Friend WithEvents lb_dot As Label
    Friend WithEvents btn_I As Button
    Friend WithEvents btn_O As Button
    Friend WithEvents btn_P As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lb_6 As Label
    Friend WithEvents lb_texto As RichTextBox
    Friend WithEvents lb_ArrowT2 As Label

End Class
